# Data
Video assets are not included. Metadata is derived from AI4Bharat INCLUDE (Sridhar, Ganesan, Kumar, Khapra, 2020), CC BY 4.0: https://zenodo.org/records/4010759 and https://huggingface.co/datasets/ai4bharat/INCLUDE .
Changes: source columns renamed to the project's schema, source split names retained, unknown signer/session values left blank. CSVs are original-family and HF-family separately. Never concatenate them as independent examples. See DATASET_REPORT.md.
