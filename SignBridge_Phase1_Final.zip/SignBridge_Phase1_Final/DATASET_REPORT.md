# Dataset inspection
Checked 2026-10-14. Primary sources:
- https://zenodo.org/api/records/4010759 (accessible API record; open access, CC BY 4.0)
- https://zenodo.org/records/4010759
- https://huggingface.co/datasets/ai4bharat/INCLUDE/blob/9530511747c03569465c6c217102ec3bbcce2fc1/README.md
- https://huggingface.co/api/datasets/ai4bharat/INCLUDE
- https://doi.org/10.1145/3394171.3413528
- https://github.com/AI4Bharat/OpenHands/releases/download/checkpoints_v1/include_metadata.zip

## Published statistics vs measurements
The original paper describes 4,287 videos, 263 word signs, 15 categories and about 0.27 million frames. The Zenodo record says five recordings were subsequently added, giving 4,292; it lists train 3,475 and test 817. INCLUDE-50 is described as 766 train and 192 test videos. These are published figures, not videos all decoded here.

The downloaded OpenHands release CSVs actually contain 3,475 training rows and 817 test rows. The newer Hugging Face card specifies 3,816 train, 425 validation and 1,009 test entries. We downloaded all three tiny parquet metadata files and measured 5,250 rows and 263 distinct exact labels. This is metadata inspection, not full video inspection.

The HF files contain 969 paths occurring more than once and **424 paths assigned across splits**. `reports/hf_cross_split_paths.json` lists them. Therefore the nominal newer split cannot be used as independent evaluation without reconciliation. The older split family is retained separately; no silent merge is performed. The newer metadata has 4,257 unique paths (3,288 occur once, 945 occur twice and 24 occur three times).

## Access, terms and storage
Hugging Face API reports `gated=false`; its metadata downloaded without credentials. Zenodo API and byte-range access were available. Downloadability of every archive was not tested. Sum of all listed asset sizes: 56,751,823,082 bytes, approximately 56.75 decimal GB / 52.85 GiB; extracted storage is not established. The card's 114,570-byte download figure describes parquet metadata, NOT all videos.

CC BY 4.0 permits sharing/adaptation subject to attribution and its terms; preserve creator credit, license link and changes: https://creativecommons.org/licenses/by/4.0/ . The dataset card asks users to respect participants' dignity/privacy and notes regional variation. Do not describe this vocabulary as all ISL. This ZIP includes derived metadata, not videos.

## Organization and identities
HF columns are parent_label, label, video_path and include_50. Example path: Greetings/51. Good Morning/MVI_9992.MOV. Older CSVs use Word/FilePath. Keep numbered/case-sensitive source labels unchanged. Do not extract signer identity from filenames or appearance. No explicit signer/session columns were available in the inspected metadata. Signer-independent evaluation cannot be established.

## Current local measurements — 16 October 2026
Source: reports/target20/inspection.json and manifest.json, generated on the user's Mac. The review workspace contains reports, not the videos; it checks report consistency only.

404 entries / 404 distinct local files decode successfully, representing 24 canonical classes. No exact duplicate hashes, unindexed videos or known-identity split conflicts were reported. No signer identities are available. Near duplicates, sign correctness and visual/landmark quality across all videos remain unreviewed. Filenames do not establish signer identity.

The local assets comprise Adjectives_4of8, Greetings_1of2, Greetings_2of2, Days_and_Time_1of3 and the Radio demo sample. This is not inspection of all INCLUDE videos. Published archive availability was checked during the earlier investigation; intermittent user-side HTTPS/timeouts occurred later. Local acquisition/extraction is evidenced by the current manifest.

## Reduced training target
The user reduced the original 30–50-class target to **20** because of the presentation deadline. Selection ranks distinct decodable non-test samples, then known signer coverage (unknown here), then canonical label. Minimum five unique non-test recordings is an eligibility rule, not a guarantee of sufficient training data. Exactly 20 are selected with **309** unique non-test recordings. The prior chat total of 312 was an arithmetic error.

| Label | Display name | Unique non-test recordings |
|---|---|---:|
| 79.short | short | 18 |
| 48.Hello | Hello | 17 |
| 49.Howareyou | How are you | 17 |
| 50.Alright | Alright | 17 |
| 51.GoodMorning | Good morning | 17 |
| 54.Goodnight | Good night | 17 |
| 55.Thankyou | Thank you | 17 |
| 56.Pleased | Pleased | 17 |
| 78.long | long | 17 |
| 80.tall | tall | 17 |
| 81.wide | wide | 17 |
| 52.Goodafternoon | Good afternoon | 16 |
| 53.Goodevening | Good evening | 14 |
| 66.Sunday | Sunday | 13 |
| 67.Monday | Monday | 13 |
| 68.Tuesday | Tuesday | 13 |
| 69.Wednesday | Wednesday | 13 |
| 70.Thursday | Thursday | 13 |
| 71.Friday | Friday | 13 |
| 72.Saturday | Saturday | 13 |

The target is provisional. Days and greetings support a simple demonstration, but practical relevance and linguistic correctness still require review. All 20 canonical labels occur in the hash-verified 263-class checkpoint map (reports/phase1_closeout.json). Label coverage alone is not performance evidence. Light, famous, Radio and Today are available locally but not selected by the capped ranking. Original label spellings and source_labels are retained; display names are separate.

## Splits and leakage
Keep the original release train/test membership. Do not merge the incompatible newer HF splits. The selected vocabulary has only non-test recordings; the seven-video diagnostic used train rows with explicit overlap opt-in. No final test inference was performed in that report. Every clip and all derived frames/features must remain in one split; augmentation follows splitting.

Known signer/source/hash/near-duplicate groups are connected before any new split. Existing supplied splits are preserved and checked. Without signer identifiers, new signer-independent splitting is blocked. Near-duplicate review is still needed; an empty detected-leakage list is not proof of signer independence or absence of visually similar recordings.

## Later adaptation path (not implemented)
Review the selected clips and ambiguous signs; obtain consented signer/session metadata where possible; identify source/near-duplicate groups; agree a development protocol without consuming reserved test data. Extract the selected recordings consistently using the pinned experimental feature contract. Train or adapt a temporal classifier with a new 20-way head and a separately stored target label order; never relabel the existing 263-way output. If historical extractor equivalence cannot be established, consistently re-extract all adaptation data and report it as a new pipeline rather than historical benchmark reproduction. Evaluate new recordings and held-out signers when identities permit.
