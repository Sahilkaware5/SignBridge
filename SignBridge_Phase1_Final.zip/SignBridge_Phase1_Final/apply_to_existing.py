"""Apply closeout files to the uploaded project version, preserving local assets."""
import argparse
import hashlib
import json
import shutil
from datetime import datetime
from pathlib import Path

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--project', required=True)
    args = parser.parse_args()
    target = Path(args.project).resolve()
    source = Path(__file__).resolve().parent
    if source == target or not (target / 'src/signbridge/labels.py').is_file():
        raise SystemExit('Choose your existing signbridge project directory.')
    changes = json.loads((source / 'update_manifest.json').read_text())
    pending = []
    for change in changes:
        relative = Path(change['path'])
        destination = (target / relative).resolve()
        origin = (source / relative).resolve()
        if not destination.is_relative_to(target) or not origin.is_relative_to(source):
            raise SystemExit('Invalid update path')
        if digest(origin) != change['after']:
            raise SystemExit('Update source checksum mismatch: ' + str(relative))
        actual = digest(destination)
        if actual == change['after']:
            continue
        if actual != change['before']:
            raise SystemExit('Local edit conflict; nothing changed: ' + str(relative))
        pending.append((origin, destination, relative))
    if not pending:
        print('Update already installed.')
        return
    backup = target / 'backups' / datetime.now().strftime('phase1_closeout_%Y%m%d_%H%M%S_%f')
    for origin, destination, relative in pending:
        if destination.exists():
            saved = backup / relative
            saved.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(destination, saved)
    for origin, destination, relative in pending:
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(origin, destination)
    print('Installed', len(pending), 'updated files. Backup:', backup)
    print('Run: python scripts/finalize_phase1.py')

if __name__ == '__main__':
    main()
