# Phase 1 results — 16 October 2026

## Decision
**Partially complete: experimental offline pipeline demonstrated; 20-class provisional target established.** All independent software, metadata and documentation work in this closeout is delivered. Do not mark all original readiness criteria verified: visual/linguistic and near-duplicate review remains pending, signer IDs are unavailable, and the historical training extractor version cannot be established from the supplied evidence. These cannot be fixed by changing labels or declaring the tests complete. No Phase 2 training has started.

## Actual evidence
- Mac terminal report: 27 tests passed in 1.56 seconds before this closeout.
- Mac inspection: 404 usable videos, 24 canonical classes, zero reported decode failures, exact duplicate groups, known-identity split leakage or unindexed videos.
- Reduced target: 20 classes and **309** unique non-test recordings (corrects earlier chat claim of 312).
- All 20 selected labels occur in the unchanged original 263-class checkpoint label map. Presence does not establish per-class recognition quality.
- Saved setup verifies checkpoint and extractor assets, no missing/unexpected state keys, exact graph match and 263-output contract. Setup's synthetic tensor is software validation only.
- Seven real train recordings processed on the Mac; six correct, one wrong, zero failures. Radio was confused with Market. No independent accuracy claim.

Sources: reports/target20/{manifest,inspection,vocabulary}.json, reports/recognition_setup.json, reports/my_stgcn_seven_classes.json, reports/my_light_result.json. The closeout audit is reports/phase1_closeout.json. Existing Linux reference evidence is retained under reports/recognition_reference. This review environment did not receive real videos or weights; no new recognition run is claimed here.

## Mac diagnostic outputs
| Expected | Predicted | Preprocessing (s) | Model inference (s) | Per-video total (s) |
|---|---|---:|---:|---:|
| 36.light | 36.light | 4.210 | 0.0142 | 4.358 |
| 39.famous | 39.famous | 4.619 | 0.0082 | 4.797 |
| 60.Radio | 32.Market | 4.576 | 0.0119 | 4.933 |
| 78.long | 78.long | 5.545 | 0.0119 | 5.761 |
| 79.short | 79.short | 5.132 | 0.0130 | 5.338 |
| 80.tall | 80.tall | 5.998 | 0.0132 | 6.222 |
| 81.wide | 81.wide | 5.120 | 0.0099 | 5.317 |

Diagnostic top-1: 6/7 = 85.71%, only on this tiny training-overlap subset. This does not measure the selected 20-class vocabulary as a whole. Model load 0.690 s; extractor initialization 0.454 s; batch total 37.946 s. Per-video totals exclude the reused model load. Mean per-video total 5.246 s. Landmark extraction dominates; these results do not establish real-time webcam performance.

Hardware recorded by diagnostic: macOS-27.2-arm64-arm-64bit, Python 3.12.10, 8 GiB RAM, torch 2.6.0, CPU recognition; MPS arithmetic passed but model acceleration was not exercised. OS strings are reported as supplied rather than inferred from product names.

## Commands actually evidenced on the Mac
```bash
python scripts/setup_recognition.py
python -m pytest -q
python scripts/run_offline.py "data/raw/Adjectives/36. light/MVI_9711.MOV" --out reports/my_light_result.json
python scripts/evaluate_diagnostic.py reports/downloaded_subset_fixed/manifest.json --root data/raw --allow-training-overlap --limit 7 --out reports/my_stgcn_seven_classes.json
python scripts/inspect_dataset.py data/raw --metadata data/manifests/all_downloaded.csv --out reports/target20
```

Closeout work additionally executed scripts/finalize_phase1.py against the uploaded reports and reran available software tests in a dedicated Linux review environment (see TESTING.md). It did not download the full dataset or run weights without assets.

## Outstanding evidence and concrete next steps
1. Review the selected clips for actual sign identity, usable body/hands and near duplicates; record exclusions and source groups. No signer identity may be invented.
2. Retain the pinned experimental extractor contract; document that exact historical reproduction remains unavailable unless upstream supplies its version/assets. A later consistently re-extracted adaptation dataset is the concrete fallback.
3. Establish a development split within original train recordings using source groups and signer metadata if obtained; preserve the final test set. Do not claim signer independence without identifiers.
4. Measure held-out and new-recording performance in later phases. The current model-score values are uncalibrated; unknown-sign rejection and webcam behavior have not been evaluated.

A reproducible adaptation path is documented in DATASET_REPORT.md. This handoff stops at Phase 1.
