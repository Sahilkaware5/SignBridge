"""Download small pinned metadata only; never downloads videos."""
import argparse,csv,json,urllib.request
from pathlib import Path
import pyarrow.parquet as pq
REV='9530511747c03569465c6c217102ec3bbcce2fc1'
p=argparse.ArgumentParser();p.add_argument('--out',default='data/manifests/hf_metadata.csv');p.add_argument('--cache',default='data/cache/metadata');a=p.parse_args()
cache=Path(a.cache);cache.mkdir(parents=True,exist_ok=True);rows=[]
for split in ['train','val','test']:
    local=cache/(split+'.parquet')
    if not local.exists():
        url=f'https://huggingface.co/datasets/ai4bharat/INCLUDE/resolve/{REV}/data/{split}-00000-of-00001.parquet'
        with urllib.request.urlopen(url,timeout=60) as r: local.write_bytes(r.read())
    for row in pq.read_table(local).to_pylist():
        rows.append(dict(relative_video_path=row['video_path'],original_label=row['label'],official_split=split,
                         signer_id='',session_id='',source_id='',include_50=row['include_50']))
Path(a.out).parent.mkdir(parents=True,exist_ok=True)
with open(a.out,'w',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
print(f'{len(rows)} metadata rows; no videos inspected. Saved {a.out}')
