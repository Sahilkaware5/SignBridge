"""Audit metadata without claiming that listed video files exist."""
import argparse,csv,json,collections
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('csv');p.add_argument('--out',default='reports/metadata_audit.json');a=p.parse_args()
rows=list(csv.DictReader(open(a.csv,encoding='utf-8-sig',newline='')))
paths=collections.Counter(r['relative_video_path'] for r in rows);groups=collections.defaultdict(set)
for r in rows:
    if r.get('official_split'):groups[r['relative_video_path']].add(r['official_split'])
result={'scope':'metadata_only_no_video_quality_claims','rows':len(rows),'unique_paths':len(paths),
        'unique_labels':len({r['original_label'] for r in rows}),
        'split_counts':dict(collections.Counter(r.get('official_split') for r in rows)),
        'duplicate_paths':{k:v for k,v in paths.items() if v>1},
        'cross_split_paths':{k:sorted(v) for k,v in groups.items() if len(v)>1},
        'missing_labels':[r['relative_video_path'] for r in rows if not r['original_label']]}
Path(a.out).parent.mkdir(parents=True,exist_ok=True);Path(a.out).write_text(json.dumps(result,indent=2))
print(f"{len(rows)} metadata rows; {len(result['cross_split_paths'])} cross-split paths; no videos decoded")
