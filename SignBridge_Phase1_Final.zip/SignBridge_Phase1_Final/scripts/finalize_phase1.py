"""Audit saved Phase 1 evidence; never substitutes for real inference or video decoding."""
import hashlib
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from signbridge.labels import canonical_label

def audit(root):
    def read(name):
        return json.loads((root / name).read_text())
    manifest = read("reports/target20/manifest.json")
    inspection = read("reports/target20/inspection.json")
    vocabulary = read("reports/target20/vocabulary.json")
    labels = read("models/checkpoint_labels.json")
    setup = read("reports/recognition_setup.json")
    diagnostic = read("reports/my_stgcn_seven_classes.json")
    errors = []
    def check(condition, message):
        if not condition: errors.append(message)
    label_hash = hashlib.sha256((root / "models/checkpoint_labels.json").read_bytes()).hexdigest()
    check(label_hash == setup.get("label_map_sha256"), "Label map differs from verified setup")
    check(len(labels) == setup.get("output_classes") == 263, "Unexpected classifier label count")
    check(setup.get("missing_weights") == [] and setup.get("unexpected_weights") == [], "Setup weight mismatch")
    check(setup.get("graph_adjacency_matches") is True and setup.get("extractor_assets_verified") is True, "Setup compatibility evidence missing")
    check(inspection["entries_examined"] == len(manifest), "Manifest/report entry count differs")
    check(inspection["usable_entries"] == sum(r["decode_status"] == "ok" for r in manifest), "Usable count differs")
    check(not inspection["split_leakage"], "Reported split leakage")
    # Independently recompute known-identity leakage without requiring OpenCV.
    for field in ("sample_id", "relative_video_path", "sha256", "source_id", "signer_id", "near_duplicate_group"):
        seen = {}
        for row in manifest:
            if row.get(field) and row.get("official_split"):
                seen.setdefault(row[field], set()).add(row["official_split"])
        check(all(len(s) == 1 for s in seen.values()), "Cross-split identity: " + field)
    check(vocabulary["requested_classes"] == vocabulary["supported_classes"] == len(vocabulary["classes"]) == 20, "20-class target not met")
    checkpoint_labels = {canonical_label(x) for x in labels}
    matches = []
    for item in vocabulary["classes"]:
        label = item["canonical_label"]
        eligible = [r for r in manifest if canonical_label(r["original_label"]) == label
                    and r["decode_status"] == "ok" and r.get("official_split") in ("train", "val", "validation", "dev")]
        count = len({r["sha256"] for r in eligible})
        check(count == item["usable_samples"] and count >= 5, "Insufficient or inconsistent development samples: " + label)
        check(label in checkpoint_labels, "Target absent from checkpoint label map: " + label)
        matches.append({"canonical_label": label, "non_test_samples": count, "checkpoint_label_present": label in checkpoint_labels})
    results = diagnostic["results"]
    successful = [r for r in results if r.get("status") == "ok" and r.get("predicted_label")]
    correct = sum(canonical_label(r["expected_label"]) == canonical_label(r["predicted_label"]) for r in successful)
    check(all(r.get("official_split") in ("train", "val", "validation", "dev") for r in results), "Diagnostic used non-development data")
    check(diagnostic.get("final_test_used") is False, "Final test exclusion not established")
    check(len(successful) == diagnostic["evaluated"] and len(successful) > 0, "Diagnostic count differs")
    if successful:
        check(abs(correct / len(successful) - diagnostic["top1_accuracy"]) < 1e-12, "Diagnostic accuracy differs")
    return {"status": "evidence_consistent" if not errors else "error", "errors": errors,
            "phase1_readiness": "partially_complete_experimental_pipeline_demonstrated",
            "scope": "20-class provisional training target; no Phase 2 training",
            "usable_videos": inspection["usable_entries"], "canonical_classes": inspection["classes_with_usable_files"],
            "selected_classes": len(matches), "selected_non_test_recordings": sum(x["non_test_samples"] for x in matches),
            "checkpoint_label_coverage": matches, "diagnostic_correct": correct, "diagnostic_evaluated": len(successful),
            "evidence_basis": "Uploaded Mac reports checked for internal consistency; videos and weights not re-executed by this audit",
            "limitations": ["Signer identities unavailable; signer independence not established",
                            "Near-duplicate and linguistic/visual review pending",
                            "Historical training extractor version unknown; pinned experimental adapter only",
                            "Diagnostic overlaps original training data and does not cover the 20-class target",
                            "Independent accuracy, webcam operation and model acceleration untested"]}

if __name__ == "__main__":
    root = Path(__file__).resolve().parents[1]
    result = audit(root)
    output = root / "reports/phase1_closeout.json"
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    print("Saved:", output)
    sys.exit(2 if result["errors"] else 0)
