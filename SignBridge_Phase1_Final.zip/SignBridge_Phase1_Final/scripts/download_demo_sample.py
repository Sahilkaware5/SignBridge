"""Fetch one recorded INCLUDE ZIP member via HTTP ranges, never the full archive.
Requires internet and a server honoring Range. Verifies ZIP CRC and recorded SHA256.
No dataset assets are distributed with this project.
"""
import io,json,urllib.request,zipfile,argparse,hashlib
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--out',default='data/raw');a=p.parse_args()
record=json.loads((Path(__file__).resolve().parents[1]/'reports/sample_source.json').read_text());asset=record['archive']
class RemoteArchive(io.RawIOBase):
    def __init__(self):self.pos=0
    def seekable(self):return True
    def readable(self):return True
    def tell(self):return self.pos
    def seek(self,offset,whence=0):
        self.pos=offset if whence==0 else self.pos+offset if whence==1 else asset['size']+offset
        if self.pos<0:raise ValueError('Negative seek')
        return self.pos
    def read(self,n=-1):
        if n<0:n=asset['size']-self.pos
        n=min(n,asset['size']-self.pos)
        if n<=0:return b''
        end=self.pos+n-1
        request=urllib.request.Request(asset['links']['self'],headers={'Range':f'bytes={self.pos}-{end}'})
        with urllib.request.urlopen(request,timeout=60) as response:
            if response.status!=206 or not response.headers.get('Content-Range','').startswith(f'bytes {self.pos}-{end}/'):
                raise RuntimeError('Server did not honor byte range; refusing full archive download')
            data=response.read(n)
        if len(data)!=n:raise RuntimeError('Incomplete range; rerun this small-member download')
        self.pos+=len(data)
        return data
root=Path(a.out).resolve();dest=(root/record['member']).resolve()
if not dest.is_relative_to(root):raise ValueError('Unsafe archive member')
with zipfile.ZipFile(RemoteArchive()) as archive:
    info=archive.getinfo(record['member'])
    if info.file_size!=record['bytes'] or info.CRC!=record['crc32']:raise RuntimeError('Remote member changed')
    content=archive.read(info)
if 'sha256' in record and hashlib.sha256(content).hexdigest()!=record['sha256']:raise RuntimeError('Sample hash mismatch')
dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(content);print(dest)
