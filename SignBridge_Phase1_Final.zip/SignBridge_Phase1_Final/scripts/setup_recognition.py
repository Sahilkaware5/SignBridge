"""Download pinned recognition assets and verify the CPU runtime. Run in a dedicated venv."""
import argparse,sys,urllib.request,urllib.error,zipfile,shutil,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from signbridge.common import digest,save
from signbridge.model_loader import read_config,resolve_asset

def download(url,dest,expected):
    dest=Path(dest);dest.parent.mkdir(parents=True,exist_ok=True)
    if dest.is_file():
        if digest(dest)==expected:print('Verified existing',dest.name,flush=True);return
        raise ValueError('Existing file has wrong hash; move it aside before retrying: '+str(dest))
    part=dest.with_suffix(dest.suffix+'.part');offset=part.stat().st_size if part.exists() else 0
    request=urllib.request.Request(url,headers={'Range':f'bytes={offset}-'} if offset else {})
    print('Downloading',dest.name,flush=True)
    with urllib.request.urlopen(request,timeout=90) as response:
        resume=offset>0 and response.status==206
        if resume and not response.headers.get('Content-Range','').startswith(f'bytes {offset}-'):
            raise ValueError('Unexpected resume offset')
        with part.open('ab' if resume else 'wb') as f:
            while chunk:=response.read(1024*1024):f.write(chunk)
    if digest(part)!=expected:raise ValueError('Download hash mismatch; remove the .part file and retry: '+str(part))
    part.replace(dest);print('Verified download',dest.name,flush=True)

def main():
    p=argparse.ArgumentParser();p.add_argument('--config',default='configs/model_stgcn.yaml');p.add_argument('--out',default='reports/recognition_setup.json');a=p.parse_args()
    try:
        if sys.prefix==sys.base_prefix:raise ValueError('Activate .venv-recognition before installing model assets')
        from importlib.metadata import version
        if sys.version_info[:2]!=(3,12):raise ValueError('Use Python 3.12 for this verified runtime')
        required={'numpy':'1.26.4','mediapipe':'0.10.21','opencv-contrib-python':'4.11.0.86','torch':'2.6.0'}
        for name,want in required.items():
            if version(name).split('+')[0]!=want:raise ValueError(f'{name} must be {want}; use requirements-recognition-mac.txt in the new environment')
        c=read_config(a.config);target=resolve_asset(c,'checkpoint_path')
        archive=target.parents[2]/'downloads/include_stgcn.zip'
        if not target.is_file():
            download(c['checkpoint_zip_url'],archive,c['checkpoint_zip_sha256'])
            member='include/st_gcn/epoch=215-step=23543.ckpt';target.parent.mkdir(parents=True,exist_ok=True)
            # Extract only the named weight member; no archive path traversal or code execution.
            with zipfile.ZipFile(archive) as z:
                with z.open(member) as source,target.with_suffix('.tmp').open('wb') as output:shutil.copyfileobj(source,output)
            if digest(target.with_suffix('.tmp'))!=c['checkpoint_sha256']:raise ValueError('Extracted checkpoint hash mismatch')
            target.with_suffix('.tmp').replace(target)
        import mediapipe as mp
        heavy='modules/pose_landmark/pose_landmark_heavy.tflite'
        download('https://storage.googleapis.com/mediapipe-assets/pose_landmark_heavy.tflite',
                 Path(mp.__file__).parent/heavy,c['extractor_assets_sha256'][heavy])
        from signbridge.inference import RecognitionPipeline
        import numpy as np
        pipeline=RecognitionPipeline(a.config)
        output,_=pipeline.model.predict(np.zeros((1,2,16,27),np.float32))
        result=dict(pipeline.model.verification,status='ready_for_experimental_offline_inference',
                    synthetic_output_shape=list(output.shape),model_load_seconds=pipeline.model.load_seconds,
                    extractor_init_seconds=pipeline.extractor.init_seconds,
                    extractor_assets_verified=True,real_sample_inference_this_command=False)
        save(a.out,result);print('Setup verified. No real prediction was made by this setup command.');return 0
    except Exception as e:
        save(a.out,{'status':'error','failure_reason':str(e)})
        print('Setup failed:',e,file=sys.stderr)
        if 'CERTIFICATE_VERIFY_FAILED' in str(e):print('On macOS, run: open "/Applications/Python 3.12/Install Certificates.command"',file=sys.stderr)
        return 2
if __name__=='__main__':raise SystemExit(main())
