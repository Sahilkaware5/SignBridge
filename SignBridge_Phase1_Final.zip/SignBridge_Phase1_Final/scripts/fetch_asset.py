"""Explicit resumable asset download with integrity check. No automatic bulk download."""
import argparse,hashlib,urllib.request,os
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('url');p.add_argument('destination');p.add_argument('--checksum',required=True,help='sha256:HEX or md5:HEX from authoritative metadata');a=p.parse_args()
algorithm,expected=a.checksum.split(':',1)
if algorithm not in ('sha256','md5'):p.error('Supported hashes: sha256/md5')
dest=Path(a.destination);dest.parent.mkdir(parents=True,exist_ok=True);part=dest.with_suffix(dest.suffix+'.part')
if not a.url.startswith('https://'):p.error('HTTPS required')
if dest.exists():p.error('Destination exists; verify it or choose another path')
offset=part.stat().st_size if part.exists() else 0
req=urllib.request.Request(a.url,headers={'Range':f'bytes={offset}-'} if offset else {})
with urllib.request.urlopen(req,timeout=60) as r:
    if offset and r.status==206 and not r.headers.get('Content-Range','').startswith(f'bytes {offset}-'):
        raise RuntimeError('Server returned an unexpected resume offset')
    mode='ab' if offset and r.status==206 else 'wb'
    with part.open(mode) as f:
        while chunk:=r.read(1024*1024):f.write(chunk)
h=hashlib.new(algorithm)
with part.open('rb') as f:
    while chunk:=f.read(1024*1024):h.update(chunk)
if h.hexdigest()!=expected:raise RuntimeError('Checksum mismatch; partial file retained for inspection')
os.replace(part,dest);print('Verified',dest)
