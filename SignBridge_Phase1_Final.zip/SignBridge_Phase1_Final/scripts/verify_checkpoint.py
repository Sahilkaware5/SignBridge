"""Restricted checkpoint inspection; does not enable sign prediction."""
import argparse,csv,json,sys,hashlib
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from signbridge.common import save,digest
p=argparse.ArgumentParser();p.add_argument('checkpoint');p.add_argument('--labels',default='models/checkpoint_labels.json');p.add_argument('--out',default='reports/checkpoint_inspection.json');a=p.parse_args()
import torch
class LegacyCheckpointMetadata: pass
class LegacyEarlyStopMetadata: pass
# Data-only stand-ins, no legacy package code imported or executed.
allow=[(LegacyCheckpointMetadata,'pytorch_lightning.callbacks.model_checkpoint.ModelCheckpoint'),
       (LegacyEarlyStopMetadata,'pytorch_lightning.callbacks.early_stopping.EarlyStopping')]
try:
    with torch.serialization.safe_globals(allow): d=torch.load(a.checkpoint,map_location='cpu',weights_only=True)
    state=d['state_dict'];labels=json.loads(Path(a.labels).read_text())
    shape=list(state['model.decoder.fc.weight'].shape)
    if shape[0]!=len(labels) or len(labels)!=len(set(labels)):raise ValueError('Output/label mismatch')
    if not all(torch.isfinite(v).all().item() for v in state.values()):raise ValueError('Non-finite checkpoint weights')
    from signbridge.architecture_probe import CheckpointProbe
    probe=CheckpointProbe().eval()
    mismatch=probe.load_state_dict(state,strict=True)
    with torch.inference_mode(): synthetic_output=probe(torch.zeros(1,2,8,27))
    if synthetic_output.shape!=(1,len(labels)): raise ValueError('Synthetic output mismatch')
    save(a.out,{'synthetic_shape_test':list(synthetic_output.shape),'status':'tensor_inspection_passed_not_runtime_verified','sha256':digest(a.checkpoint),
        'pytorch_version':torch.__version__,'original_lightning_version':d.get('pytorch-lightning_version'),
        'output_classes':shape[0],'label_count':len(labels),'weights':{k:list(v.shape) for k,v in state.items()},
        'strict_architecture_load':'passed on source-derived structural probe only','missing_weights':list(mismatch.missing_keys),'unexpected_weights':list(mismatch.unexpected_keys),
        'warning':'Current upstream BiLSTM source has batch/time axis ambiguity; this script does not establish recognition compatibility.'})
    print('Checkpoint tensors and 263-label count inspected. Recognition remains blocked.')
except Exception as e:
    save(a.out,{'status':'error','failure_reason':str(e)});raise SystemExit(2)
