# Install into your existing Mac project

Extract this ZIP in Downloads. From your existing signbridge project folder run:
```bash
source .venv-recognition/bin/activate
python ~/Downloads/SignBridge_Phase1_Final/apply_to_existing.py --project .
python scripts/finalize_phase1.py
```
The updater backs up changed files, checks them against the uploaded review snapshot, and refuses conflicting local edits. It copies only changed/new project files. Your videos, weights, environments and other files stay in place. No package reinstall or dataset re-download is required. If it reports a conflict, keep the local file and inspect the difference rather than forcing an overwrite.

You can also read this extracted project independently. It intentionally excludes videos, weights and virtual environments, so fresh installations require the acquisition steps in README.md. The existing Mac installation is the fastest demo route.
