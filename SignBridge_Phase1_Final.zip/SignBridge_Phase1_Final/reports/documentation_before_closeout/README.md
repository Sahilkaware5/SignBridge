# SignBridge — experimental offline ISL recognition

Phase 1 now includes real isolated-sign video recognition using the official OpenHands INCLUDE ST-GCN classifier and pinned MediaPipe Holistic extraction. It is not continuous translation. No training, webcam loop, LLM, speech or full interface is implemented.

**Phase 1 is partially complete.** The real inference milestone works on Linux CPU. Your inspected subset supports six provisional training classes, not the intended 30–50. Mac performance and independent generalization remain unverified.

## Mac setup (from your existing signbridge folder)
Keep your current .venv312 for the previous dataset tooling. Create a separate recognition environment because this extractor requires NumPy 1.x and a different OpenCV distribution.

```bash
python3.12 -m venv .venv-recognition
source .venv-recognition/bin/activate
python -m pip install -r requirements-recognition-mac.txt
python scripts/setup_recognition.py
python -m pytest -q
python scripts/check_environment.py --out reports/my_mac_recognition_environment.json
```

Setup downloads the official ST-GCN archive and heavy pose model, verifies SHA256 hashes, loads every weight strictly and checks a synthetic output shape. It does not perform recognition or measure accuracy. Downloads resume where supported. Python 3.12 is required for this tested dependency set. Do not install requirements.txt or requirements-dev.txt into this new environment. macOS execution is untested; the packaged cp312 universal2 model assets were compared to Linux. CPU is the only enabled inference device. Old requirements remain for the previous indexing environment.

Linux reproduction: install requirements-recognition.txt in a Python 3.12 venv, then install torch==2.6.0 from https://download.pytorch.org/whl/cpu. That wheel index is not for Mac.

## Run a real video you already downloaded
```bash
python scripts/run_offline.py "data/raw/Adjectives/36. light/MVI_9711.MOV" --out reports/my_light_result.json
```

The command validates and decodes the video, extracts joints, normalizes all frames, runs the actual checkpoint and saves its five highest model scores. The new default is configs/model_stgcn.yaml. It uses all 263 original classifier labels; vocabulary.json is not its output label map. A high score does not establish correctness or identify unsupported signs. Corrupt or unusable input produces an error and no forced prediction. Model loading, preprocessing and inference timings are separate. Optional `--cache-dir data/cache/stgcn` caches versioned landmarks.

## Index and diagnostic evaluation
Your existing imported metadata remains valid, including the explicit six spacing aliases:
```bash
python scripts/inspect_dataset.py data/raw --metadata data/manifests/downloaded_subset.csv --out reports/downloaded_subset_fixed
python scripts/evaluate_diagnostic.py reports/downloaded_subset_fixed/manifest.json --root data/raw --allow-training-overlap --limit 6 --out reports/my_stgcn_diagnostic.json
```

The explicit training-overlap flag permits original train recordings solely for pipeline checks. Test rows are never selected. Without it, only explicit dev/validation rows qualify. The tool checks split leakage and file hashes, chooses classes round-robin before inference and loads the model once. Accuracy on these original training samples is not independent generalization evidence. Do not tune using reserved test data. Signer identities are unavailable, so signer-independent evaluation is not established.

For a new data import, metadata CSV requires relative_video_path and original_label; optional signer_id, session_id, source_id, official_split and near_duplicate_group stay blank when unknown. Official INCLUDE is category/word/video nesting. Use metadata for it, not flat class-folder mode. Absolute paths in examples from old documentation are placeholders, not existing directories. See DATASET_REPORT.md for acquisition, terms, published statistics and metadata issues. Download only selected archives via scripts/fetch_asset.py using the exact URL and checksum from https://zenodo.org/api/records/4010759 . Do not combine the newer HF split with original release splits. Videos and weights are excluded from this update.

## Modules
- dataset_index / dataset_validation: metadata, decoding, hashes, duplicate and leakage checks.
- labels / vocabulary / splits: retain source labels, resolve reviewed aliases, propose actual data-supported classes, group signer/source recordings.
- landmarks / preprocessing: pinned two-hand and body extraction, source-compatible joint selection and clip normalization, provenance caches.
- vendor / stgcn_model / model_loader: minimal upstream architecture, exact checkpoint hashes and strict state/output checks.
- inference / diagnostics: structured predictions and errors, timing and development-only evaluation.
- environment: architecture, RAM, Python/package versions and device arithmetic. Its generic selected_model_cpu_verified=false means this command does not load a checkpoint; setup/inference reports contain actual model verification.

## Troubleshooting
No pytest: install requirements-recognition-mac.txt in the activated new venv. NumPy/cv2 errors: do not mix the old and recognition environments. SSL certificate failure on python.org macOS Python: run `open "/Applications/Python 3.12/Install Certificates.command"`, then retry; do not disable TLS. Missing assets: rerun setup. Checksum mismatch: move the mismatched file aside and download the official asset again. Missing video: check the actual extracted path. Missing shoulders/hands: inspect the clip; do not force a word. A bad prediction is model error, not proof of a setup failure. Never reorder checkpoint labels to fix a prediction.

Read MODEL_COMPATIBILITY.md for exact sources and limitations, PHASE1_RESULTS.md for actual outputs, TESTING.md for verification and CHANGELOG.md for this update. Historical reports are retained; the new measured evidence is under reports/recognition_reference/.
