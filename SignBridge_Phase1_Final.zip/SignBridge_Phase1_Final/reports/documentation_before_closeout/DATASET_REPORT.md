# Dataset inspection
Checked 2026-10-14. Primary sources:
- https://zenodo.org/api/records/4010759 (accessible API record; open access, CC BY 4.0)
- https://zenodo.org/records/4010759
- https://huggingface.co/datasets/ai4bharat/INCLUDE/blob/9530511747c03569465c6c217102ec3bbcce2fc1/README.md
- https://huggingface.co/api/datasets/ai4bharat/INCLUDE
- https://doi.org/10.1145/3394171.3413528
- https://github.com/AI4Bharat/OpenHands/releases/download/checkpoints_v1/include_metadata.zip

## Published statistics vs measurements
The original paper describes 4,287 videos, 263 word signs, 15 categories and about 0.27 million frames. The Zenodo record says five recordings were subsequently added, giving 4,292; it lists train 3,475 and test 817. INCLUDE-50 is described as 766 train and 192 test videos. These are published figures, not videos all decoded here.

The downloaded OpenHands release CSVs actually contain 3,475 training rows and 817 test rows. The newer Hugging Face card specifies 3,816 train, 425 validation and 1,009 test entries. We downloaded all three tiny parquet metadata files and measured 5,250 rows and 263 distinct exact labels. This is metadata inspection, not full video inspection.

The HF files contain 969 paths occurring more than once and **424 paths assigned across splits**. `reports/hf_cross_split_paths.json` lists them. Therefore the nominal newer split cannot be used as independent evaluation without reconciliation. The older split family is retained separately; no silent merge is performed. The newer metadata has 4,257 unique paths (3,288 occur once, 945 occur twice and 24 occur three times).

## Access, terms and storage
Hugging Face API reports `gated=false`; its metadata downloaded without credentials. Zenodo API and byte-range access were available. Downloadability of every archive was not tested. Sum of all listed asset sizes: 56,751,823,082 bytes, approximately 56.75 decimal GB / 52.85 GiB; extracted storage is not established. The card's 114,570-byte download figure describes parquet metadata, NOT all videos.

CC BY 4.0 permits sharing/adaptation subject to attribution and its terms; preserve creator credit, license link and changes: https://creativecommons.org/licenses/by/4.0/ . The dataset card asks users to respect participants' dignity/privacy and notes regional variation. Do not describe this vocabulary as all ISL. This ZIP includes derived metadata, not videos.

## Organization and identities
HF columns are parent_label, label, video_path and include_50. Example path: Greetings/51. Good Morning/MVI_9992.MOV. Older CSVs use Word/FilePath. Keep numbered/case-sensitive source labels unchanged. Do not extract signer identity from filenames or appearance. No explicit signer/session columns were available in the inspected metadata. Signer-independent evaluation cannot be established.

## Vocabulary and quality
The machine-readable local inspection and vocabulary outputs are in data/manifests/local_sample/ when a sample download succeeds. These distinguish accessible videos from metadata-only entries. The real downloaded clip decodes to 56 frames at 25 FPS (2.24 seconds); the legacy label is `60.Radio`, while its directory contains `60. Radio`. The exact legacy label is preserved. One or a few clips do not support a justified 30–50-class training target. The vocabulary generator requires at least five distinct decodable non-test recordings per class by default. No hand-picked convenient word list is passed off as dataset evidence. To finalize a target, acquire sufficient development recordings for 30–50 original labels, inspect quality, review practical relevance with an ISL signer and establish extractor consistency. The 263 checkpoint labels are separate from any new vocabulary.

## Split plan
Preserve original test membership as reserved. Diagnose only explicit validation/development recordings; a legacy train clip may demonstrate decoding but is not an independent held-out benchmark. New splits group shared signer IDs, exact hashes and supplied source/near-duplicate IDs as connected components. Splitting refuses unknown signers instead of making a signer-independent claim. Official assignments are never silently changed; conflicts stop planning. No frame-level split or augmentation is performed. Near-duplicate and signer review remain outstanding.

## Recognition update — 2026-10-15
The user-reported local subset has 102 usable files across seven canonical meanings after the explicit spacing-alias fix: light8, famous8, Radio1, long21, short22, tall21, wide21. Six are provisional training candidates; test rows stay excluded. These are not full-dataset statistics. Development directly tested four original training videos (light, Radio, short, tall), indexed in reports/recognition_development. No new official test predictions were made. See PHASE1_RESULTS.md and reports/recognition_reference/sample_sources.json.

The four-file development manifest/inspection are also packaged under reports/recognition_reference/recognition_development/.
