# Recognition compatibility — 2026-10-15

**Experimental real-video inference verified on Linux CPU using INCLUDE ST-GCN.** The previous BiLSTM remains disabled; its batch/time ambiguity was not patched. Its investigation is preserved in models/LEGACY_BILSTM_REVIEW.md.

## Exact provenance and assets
- Source: https://github.com/AI4Bharat/OpenHands/tree/b9ccf9eaf2a71301fc4601a64a6af06fdef04c9b
- Official checkpoint: https://github.com/AI4Bharat/OpenHands/releases/download/checkpoints_v1/include_stgcn.zip
- ZIP SHA256: bf79d52c168c5db98ad6c403846abd8712241eae7f5f1d40233eb3eae8c9346e
- Weight member: include/st_gcn/epoch=215-step=23543.ckpt
- Weight SHA256: 4431c46087b2f71a824274a4654179e7bcc7d443cbc60bb95d12a9f11361c7ef
- Metadata: https://github.com/AI4Bharat/OpenHands/releases/download/checkpoints_v1/include_metadata.zip
- Label map: models/checkpoint_labels.json; SHA256 136fbaad8b0095ce75bb32c081fd2a0b599b99efbffdaf35e15672993b02c12e. The 263 original training labels are sorted exactly as INCLUDEDataset does. They are not replaced by the proposed training vocabulary.
- Extractor: https://pypi.org/project/mediapipe/0.10.21/ ; legacy solutions.holistic, not the new Tasks API.
- Heavy pose asset: https://storage.googleapis.com/mediapipe-assets/pose_landmark_heavy.tflite ; SHA256 59e42d71bcd44cbdbabc419f0ff76686595fd265419566bd4009ef703ea8e1fe. All bundled graph/model fingerprints are pinned in configs/model_stgcn.yaml.

Code is Apache 2.0 (LICENSE-OpenHands.txt). A distinct checkpoint-specific license/model card was not found in the release; do not assume code licensing establishes redistribution permission. We provide the official download procedure, not weights or videos. MediaPipe source is Apache 2.0; its package supplies the other model resources. Review upstream terms before distributing third-party assets.

## Why this model and extractor match
This is **case 1: a supervised classifier for the original 263 INCLUDE Indian Sign Language labels**, not a newly trained six-class model. Architecture: ten spatial graph/temporal convolution blocks, learned edge weights, global average pooling, 256-feature representation, 263-way fully connected classifier. The release uses a 27-node graph with **distance** partitions. A newer example config defaults to spatial partitions, so using that default would be incompatible. We use the downloaded release config, preserved in models/stgcn_source_config.yaml (its original machine paths are evidence only).

The minimal runtime vendors the upstream ST-GCN, graph utilities and FC code. Only OmegaConf conversion is removed, accepting a plain dictionary. No learned weights or forward axis behavior are changed. This avoids installing legacy Lightning and the unresolved BiLSTM. The checkpoint records Lightning 1.4.8; inference uses torch 2.6.0. Restricted weights_only loading allows only two inert callback metadata stand-ins. All state keys load strictly, adjacency equals the release graph, weights are finite, and output count is 263. Missing and unexpected keys are recorded; important mismatches stop inference.

## Video-to-tensor contract
Read OpenCV frames in temporal order; convert BGR to RGB without mirroring or resizing. Holistic uses video mode, model_complexity=2, smoothing, detection/tracking thresholds 0.5. Face landmarks are not input features. Concatenate pose33 + left hand21 + right hand21, preserving extractor identities. Each joint is x,y,z in image-normalized extractor coordinates; model input uses x,y only. The exact 27 indices are in preprocessing.MINIMAL_27 and upstream PoseSelect.

Center the entire clip at its average shoulder midpoint; divide by average shoulder distance. Input is **[1,2,T,27]**, with every decoded frame and variable T. No resampling, augmentation, horizontal flipping, padding or truncation is applied. Single-video inference needs no padding mask. Clips over 30 seconds or 1800 frames are rejected explicitly rather than cut. Nominal duration uses frame count/FPS, not a variable-frame-rate timestamp audit.

Upstream zero-fills missing components. This adapter does the same before normalization and warns for partial hand absence. It conservatively rejects clips with no detected hand throughout, any missing shoulder confidence, nonfinite coordinates or degenerate shoulder scale. This extra quality gate is our policy, not trained unknown-sign rejection. Cache keys include source hash; metadata includes extractor version, asset hashes, options and preprocessing version. Invalid caches regenerate.

## What remains uncertain
The original training MediaPipe version and complete model-asset fingerprints are not published. We verified documented joint conventions, source transforms, checkpoint loading and actual predictions with pinned 0.10.21. This establishes an experimental compatible pipeline, not exact reproduction of historical benchmark numbers. Four original training recordings were processed, so overlap with pretraining is expected. No unseen-signer generalization is established.

The runtime was executed on Linux x86_64, Python 3.12.14, CPU. Mac cp312 universal2 MediaPipe wheel model fingerprints match Linux resources, but Mac execution/speed and MPS are untested. Only CPU is enabled. Use a separate Python 3.12 environment: NumPy 1.26.4, opencv-contrib 4.11.0.86, MediaPipe 0.10.21, torch 2.6.0. Do not combine NumPy 2/headless OpenCV requirements with this runtime.

For a viva: Holistic turns movement into joint sequences; normalization reduces position/scale differences; ST-GCN models connected joints across time; the classifier maps to its original labels. Scores can be confidently wrong. See PHASE1_RESULTS.md.
