# Phase 1 results — recognition update, 2026-10-15

## Actual execution
The official INCLUDE ST-GCN checkpoint loaded with no missing or unexpected keys. Graph adjacency and original 263-class output mapping matched. MediaPipe Holistic 0.10.21 extracted real video landmarks and the full pipeline produced four predictions. No training or random-weight recognition was used.

Development commands (venv Python, run from project root):
```bash
python scripts/inspect_dataset.py ../research/videos --metadata data/manifests/recognition_development.csv --out reports/recognition_development
python scripts/evaluate_diagnostic.py reports/recognition_development/manifest.json --root ../research/videos --allow-training-overlap --limit 4 --out reports/stgcn_diagnostic.json
python -m pytest -q
```
The research/videos path was local to development; on your Mac use data/raw and your existing manifest as shown in README. Source video paths/hashes and download provenance are packaged, not videos. The four samples were chosen from original train metadata before prediction; three adjective clips were selected by smallest compressed size in their class to reduce download size. Radio was the earlier demo clip. No final test recording was used.

| Expected | Predicted | Preprocessing (s) | Inference (s) |
|---|---|---:|---:|
| 36.light | 36.light | 4.745 | 0.037 |
| 60.Radio | 32.Market | 4.753 | 0.026 |
| 79.short | 79.short | 3.675 | 0.022 |
| 80.tall | 80.tall | 4.293 | 0.029 |

Evaluated 4, preprocessing failures 0, diagnostic top-1 3/4 (75%). Radio was mistaken for Market with model score 0.99928. **This tiny training-overlap subset is not an independent accuracy estimate.** The original training metadata establishes expected overlap with checkpoint training, although the exact training run file list was not reconstructed. No accuracy target is promised.

Model load: 1.034s; extractor import/asset validation: 0.500s; complete diagnostic batch: 19.795s. Creating a fresh Holistic graph per clip is included in preprocessing. Per-video totals additionally include validation/hashing. Linux x86_64, Python 3.12.14, torch 2.6.0+cpu, two Torch threads, approximately 9.73 GiB system RAM. CPU model inference is tens of milliseconds; landmark extraction dominates at several seconds per short clip. These are not Mac or real-time webcam measurements.

Full raw outputs: reports/recognition_reference/stgcn_diagnostic.json. A separately measured first Radio run is also preserved. Mac wheel asset comparison verifies resources only, not Mac runtime performance. TESTING.md separates automated tests from real-data checks.

## Dataset status and readiness
Your supplied inspection report shows 102 decodable local videos, seven canonical classes, no exact duplicate hashes or detected split overlap. Six classes have enough non-test recordings for a provisional training target; Radio has just one. Original label spellings and split assignments are preserved. Near duplicates and signer identities remain unresolved. These user-side observations are distinct from the four videos directly tested here.

**Overall status: partially complete; do not begin Phase 2 training yet.** The inference milestone is achieved, but 30–50-class coverage is not established, linguistic/visual review remains pending, and exact historical extractor reproduction is unknown. The next gates are a local Mac inference run, review of real outputs and landmark failures, and a justified larger training vocabulary with split limitations documented. No signer-independent claim is possible with current metadata.

A concrete later adaptation path is to extract all selected data consistently with this pinned pipeline, preserve official test data, establish development splits before augmentation, and fine-tune the temporal classifier with a new correctly sized head for the chosen vocabulary. Retain original-label/canonical mappings. This is a future training plan, not implemented training or evidence of unseen-signer performance.

The four-file development manifest/inspection are also packaged under reports/recognition_reference/recognition_development/.
