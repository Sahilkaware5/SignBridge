# Verification — recognition update

## Automated software checks
Run in the dedicated recognition environment from the project root:
```bash
python -m pytest -q
python -m pip check
```
Measured result: **27 passed in 1.47s**, no broken requirements. Report: reports/recognition_reference/software_tests.txt. Tests cover corrupt/missing/empty video, label alias stability, duplicate/leakage grouping, conservative missing-landmark policy, temporal and left/right ordering, cache provenance, output dimensions, actual checkpoint variable lengths, missing/unexpected/nonfinite weights, graph mismatch and label reordering. Actual checkpoint tests explicitly skip when assets are absent; run setup first to exercise them. Synthetic tensors in these tests are shape/contract checks, never accuracy evidence.

NumPy preprocessing was also compared against PoseSelect + CenterAndScaleNormalize from the exact upstream commit on real Radio landmarks: maximum absolute difference 5.36e-7, rtol1e-5/atol1e-6. Report: preprocessing_comparison.json. The comparison does not establish equivalence to unknown historical extractor binaries.

## Real-data checks
Four original INCLUDE train clips were sequentially decoded, extracted and classified through the diagnostic CLI: light, Radio, short, tall. Three correct, Radio confused with Market; no preprocessing failures. Raw outputs/times/hardware are in reports/recognition_reference/stgcn_diagnostic.json. Single-video run_offline.py also classified light; a second run exercised the landmark cache. These overlap the original training split and are not independent generalization evidence. No official test inference was run.

Setup verified the actual SHA256-pinned checkpoint, every extractor resource, strict state keys, graph adjacency and 263-way output. Setup's zero input is a clearly labelled synthetic software check only. Dependencies were rebuilt successfully in a fresh venv and setup repeated. requirements-recognition-constraints.txt records the resolved runtime packages; torch is platform-specific and pinned separately.

## Not verified
Mac execution/performance, MPS/CUDA, webcam behavior, unknown-sign rejection, linguistic validity, unseen-signers, 30–50-class target quality, historical training MediaPipe version, full dataset coverage or near-duplicate absence. Mac wheel bundled assets were compared, not executed. Root-level older reports are historical BiLSTM evidence; new evidence is under recognition_reference.

## Local reproduction on your Mac
```bash
python scripts/setup_recognition.py
python -m pytest -q
python scripts/run_offline.py "data/raw/Adjectives/36. light/MVI_9711.MOV" --out reports/my_light_result.json
python scripts/evaluate_diagnostic.py reports/downloaded_subset_fixed/manifest.json --root data/raw --allow-training-overlap --limit 6 --out reports/my_stgcn_diagnostic.json
```
Report your actual outputs; do not assume identical timings or predictions across platforms. Keep official test recordings reserved.
