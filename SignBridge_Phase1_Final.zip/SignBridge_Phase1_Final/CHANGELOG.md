# Changelog
## 0.1.0 — 2026-10-14
- Created modular isolated-video Phase 1 project; no existing project files were available in the workspace or found by the SignBridge title search.
- Added metadata imports, streaming full-video checks, stable labels, exact duplicate detection and leakage reporting.
- Added provisional vocabulary generation and conservative grouped split planning.
- Inspected official INCLUDE metadata and OpenHands BiLSTM release; recorded split discrepancies, cross-split duplicate paths and runtime limitations.
- Added candidate pose preprocessing/cache validation, restricted checkpoint verification and fail-closed CLI results.
- Added focused software checks and evidence reports. No training or Phase 2 features added.

## 0.2.0 — 2026-10-15
Added verified INCLUDE ST-GCN runtime, pinned Holistic extraction, checksum-verified resumable setup, versioned landmark cache, real offline top-five results and development diagnostic selection with explicit training-overlap flag. Preserved reviewed aliases, original labels, split assignments and legacy BiLSTM blocker. Four real train clips processed (3 correct, no generalization claim). Added isolated recognition requirements and updated evidence/docs. No Phase 2 training.

## 0.3.0 — 2026-10-16
- Closed out uploaded Mac evidence: 404 videos, 24 canonical classes, revised 20-class target and corrected 309 selected non-test recordings.
- Audited all selected labels against the original hash-verified checkpoint mapping; retained original output positions and aliases v4.
- Added repeatable saved-evidence audit, focused regression checks and demonstration guide.
- Aligned standalone vocabulary default to 20 and Python metadata to the documented 3.12 runtime.
- Replaced stale six-class/Linux-only documentation with actual Mac outputs and timing. Kept historical reports under their original paths and old documentation in reports/documentation_before_closeout.
- No changes to model weights, joint mapping, temporal processing, official splits or recognition forward operations. No Phase 2 features.
