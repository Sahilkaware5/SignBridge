# Phase 1 verification — 16 October 2026

## Checks executed in this closeout
Dedicated Linux review venv: Python 3.12, NumPy 1.26.4, OpenCV headless 4.11.0.86, PyYAML 6.0.3 and pytest 9.0.2. This is a software-review environment, not a replacement for the Mac recognition dependencies. Exact review versions are in reports/closeout_review_freeze.txt.

```bash
python -m pytest -q
python scripts/finalize_phase1.py
```
Result: **24 passed, 6 skipped** (reports/closeout_software_tests.txt). The six actual-checkpoint tests skipped because torch/weights are absent from this review environment. No newly executed real-video inference is claimed here. The audit independently checks report counts, known-identity split leakage, per-class unique eligible recordings, original label-map hash, saved strict setup fields, and diagnostic accuracy/test exclusion. It reports 20 labels / 309 selected non-test recordings, all present in the original checkpoint map. It audits evidence, not the omitted videos or weights.

New tests check saved-evidence consistency, rejection of a reordered checkpoint label map, and the new day-label aliases without generic normalization. Existing tests cover corrupt/empty/missing videos, stable IDs, source preservation, duplicate/source/signer grouping, shape/finite values, missing hands/shoulders, temporal and left/right identity, cache provenance and output/label dimensions. Synthetic AVI/tensor tests are software tests, not sign recognition evidence.

## Previously executed on the target Mac
User supplied terminal evidence: **27 passed in 1.56 seconds** before this closeout, including installed recognition assets. Mac setup report records strict weight and extractor verification. The seven-video diagnostic completed with 7 evaluated, 0 failures and 6 correct. All samples were original train recordings; final_test_used is false. Actual predictions, times and hardware are in reports/my_stgcn_seven_classes.json and PHASE1_RESULTS.md. This is not independent generalization or evaluation of all 20 target classes.

The earlier Linux reference run (27 passed) and comparison against upstream transforms remain under reports/recognition_reference. NumPy vs source transform maximum difference was 5.36e-7 on real Radio landmarks; that does not prove equality with unknown historical extractor binaries.

## Reproduce on your existing Mac
```bash
source .venv-recognition/bin/activate
python -m pytest -q
python scripts/finalize_phase1.py
```
The full updated suite collects 30 cases; actual pass/skip totals depend on assets. Do not label skipped tests as passed. No repeated setup/download is necessary if the existing environment works.

## Checks not performed
New recognition execution in the closeout workspace, 20-class diagnostic coverage, complete dataset decoding, signer-independent evaluation, near-duplicate review, linguistic correctness, historical extractor-version equivalence, MPS/CUDA recognition, webcam compatibility and calibrated unknown-sign rejection. Reports clearly preserve these limits.
