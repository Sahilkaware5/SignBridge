# Attribution
Dataset metadata: INCLUDE: A Large Scale Dataset for Indian Sign Language Recognition, Advaith Sridhar, Rohith Gandhi Ganesan, Pratyush Kumar, Mitesh Khapra; ACM Multimedia 2020, DOI 10.1145/3394171.3413528. CC BY 4.0: https://creativecommons.org/licenses/by/4.0/ . Source URLs and transformations are documented in DATASET_REPORT.md.

Architecture probe, selected landmark indices and normalization are adapted from AI4Bharat/OpenHands at b9ccf9eaf2a71301fc4601a64a6af06fdef04c9b, Apache License 2.0. Original repository: https://github.com/AI4Bharat/OpenHands . Changes: reduced standalone structural probe, NumPy preprocessing, explicit validation and conservative error handling. Full upstream license is included as LICENSE-OpenHands.txt. Checkpoint-specific redistribution terms were not independently established; weights are excluded.

Recognition update: src/signbridge/vendor/st_gcn.py, graph_utils.py and fc.py adapt openhands/models/encoder/graph/st_gcn.py, graph_utils.py and openhands/models/decoder/fc.py at the above commit. Changes: replace OmegaConf container conversion with plain dict; preserve model forward operations. The wrapper selects the release distance graph and 263-way FC. MediaPipe 0.10.21 is an external Apache-2.0 dependency, not vendored. Assets are downloaded separately.

Closeout packaging: the uploaded review omitted LICENSE-OpenHands.txt. The standard Apache License 2.0 text was restored from the review system common-licenses distribution; upstream attribution and commit are retained above. This is not a new grant for model weights.
