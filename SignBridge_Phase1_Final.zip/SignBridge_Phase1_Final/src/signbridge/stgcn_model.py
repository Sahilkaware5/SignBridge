"""Official INCLUDE ST-GCN architecture; no retraining or output relabeling."""
from torch import nn
from .vendor.st_gcn import STGCN
from .vendor.fc import FC
EDGES = [[2,0],[1,0],[0,3],[0,4],[3,5],[4,6],[5,7],[6,17],[7,8],[7,9],[9,10],
         [7,11],[11,12],[7,13],[13,14],[7,15],[15,16],[17,18],[17,19],[19,20],
         [17,21],[21,22],[17,23],[23,24],[17,25],[25,26]]
class Network(nn.Module):
    def __init__(self):
        super().__init__()
        self.encoder = STGCN(in_channels=2,graph_args=dict(num_nodes=27,center=0,inward_edges=EDGES,strategy='distance'),edge_importance_weighting=True)
        self.decoder = FC(n_features=256,num_class=263,dropout_ratio=0.05)
    def forward(self,x):return self.decoder(self.encoder(x))
class ReleasedSTGCN(nn.Module):
    def __init__(self):super().__init__();self.model=Network()
    def forward(self,x):return self.model(x)
