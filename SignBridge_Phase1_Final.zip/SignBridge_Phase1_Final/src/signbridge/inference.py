from time import perf_counter
from pathlib import Path
import numpy as np
from .common import digest
from .dataset_validation import probe_video
from .model_loader import load_verified_model,AssetBlocked
from .labels import canonical_label

class RecognitionPipeline:
    def __init__(self,config,device='cpu'):
        self.model=load_verified_model(config,device)
        from .landmarks import HolisticExtractor
        self.extractor=HolisticExtractor(self.model.config['extractor_assets_sha256'])

def run(video,config,pipeline=None,cache_dir=None,device='cpu'):
    start=perf_counter();provided=pipeline is not None
    result={'input_sample_identifier':Path(video).name,'model_identifier':'openhands-include-stgcn-v1',
        'checkpoint_identifier':None,'predicted_label':None,'canonical_predicted_label':None,'top_candidates':[],
        'preprocessing_seconds':None,'inference_seconds':None,'model_load_seconds':None,
        'extractor_init_seconds':None,'device':None,'warnings':[
            'Experimental isolated-sign result; scores are uncalibrated, not evidence of supported-sign membership',
            'MediaPipe 0.10.21 uses the documented extractor family/order; exact historical training extractor version is unknown'],
        'status':'error'}
    try:
        info=probe_video(video);result['video_duration_seconds']=info['duration_seconds']
        result['video_validation_seconds']=perf_counter()-start
        if info['decode_status']!='ok':raise ValueError(info['failure_reason'])
        if info['duration_seconds']>30 or info['frame_count']>1800:
            raise ValueError('Clip exceeds isolated-sign safety limit (30 seconds or 1800 frames); no automatic truncation performed')
        result['input_sha256']=digest(video)
        if pipeline is None:pipeline=RecognitionPipeline(config,device)
        model=pipeline.model
        result.update(checkpoint_identifier=model.config['checkpoint_sha256'],device=model.device,
            model_load_seconds=0.0 if provided else model.load_seconds,
            extractor_init_seconds=0.0 if provided else pipeline.extractor.init_seconds,
            runtime_verification=model.verification,model_reused=provided)
        features,details=pipeline.extractor.extract(video,info['frame_count'],cache_dir)
        result['preprocessing_seconds']=details['seconds'];result['preprocessing']=details
        result['warnings'].extend(details['warnings'])
        logits,elapsed=model.predict(features);result['inference_seconds']=elapsed
        # Softmax is a model score, not calibrated confidence or unknown rejection.
        exp=np.exp(logits-logits.max());scores=exp/exp.sum();order=np.argsort(-scores,kind='stable')[:5]
        result['top_candidates']=[{'output_index':int(i),'label':model.labels[i],
            'canonical_label':canonical_label(model.labels[i]),'model_score':float(scores[i])} for i in order]
        result['predicted_label']=model.labels[int(order[0])]
        result['canonical_predicted_label']=canonical_label(result['predicted_label'])
        result['score_type']='uncalibrated_softmax';result['status']='ok'
    except AssetBlocked as e:result.update(status='blocked',failure_reason=str(e))
    except (OSError,ValueError,RuntimeError,ImportError,KeyError) as e:result.update(status='error',failure_reason=str(e))
    result['total_processing_seconds']=perf_counter()-start
    return result
