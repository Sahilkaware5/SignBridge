from pathlib import Path
import math
import cv2

def probe_video(path):
    result = dict(duration_seconds=None, fps=None, frame_count=0, width=None, height=None,
                  decode_status='error', failure_reason=None, metadata_frame_count=None)
    path = Path(path)
    if not path.is_file():
        result['failure_reason'] = 'missing_file'; return result
    if path.stat().st_size == 0:
        result['failure_reason'] = 'empty_file'; return result
    cap = cv2.VideoCapture(str(path))
    try:
        if not cap.isOpened():
            result['failure_reason'] = 'unreadable_video'; return result
        fps = float(cap.get(cv2.CAP_PROP_FPS))
        declared = cap.get(cv2.CAP_PROP_FRAME_COUNT)
        result['metadata_frame_count'] = int(declared) if math.isfinite(declared) else None
        if math.isfinite(fps) and fps > 0: result['fps'] = fps
        sizes = set()
        while True:
            ok, frame = cap.read()
            if not ok: break
            if frame is None or frame.size == 0: break
            result['frame_count'] += 1
            sizes.add((frame.shape[1], frame.shape[0]))
        if not result['frame_count']: result['failure_reason'] = 'no_decodable_frames'
        elif len(sizes) != 1: result['failure_reason'] = 'inconsistent_frame_dimensions'
        elif result['fps'] is None: result['failure_reason'] = 'invalid_fps'
        elif result['metadata_frame_count'] and abs(result['frame_count'] - result['metadata_frame_count']) > 1:
            result['failure_reason'] = 'decoded_frame_count_mismatch'
        else: result['decode_status'] = 'ok'
        if sizes: result['width'], result['height'] = next(iter(sizes))
        if result['fps']: result['duration_seconds'] = result['frame_count'] / result['fps']
    finally: cap.release()
    return result

def leakage_issues(rows, split_key='official_split'):
    problems = []
    for key in ['sample_id', 'relative_video_path', 'sha256', 'source_id', 'signer_id', 'near_duplicate_group']:
        seen = {}
        for r in rows:
            value, split = r.get(key), r.get(split_key)
            if value is None or value == '' or split is None: continue
            seen.setdefault(value, set()).add(split)
        for value, splits in seen.items():
            if len(splits) > 1: problems.append({'field': key, 'value': value, 'splits': sorted(splits)})
    return problems
