"""Explicit aliases verified in the user's INCLUDE subset; no generic cleanup.
Original labels and checkpoint output positions must always be retained.
"""
LABEL_MAPPING_VERSION = "include-subset-aliases-v4"
ALIASES = {
    '53. Good evening': '53.Goodevening',
    '54. Good night': '54.Goodnight',
    '55. Thank you': '55.Thankyou',
    '56. Pleased': '56.Pleased',
    '48. Hello': '48.Hello',
    '49. How are you': '49.Howareyou',
    '50. Alright': '50.Alright',
    '51. Good Morning': '51.GoodMorning',
    '52. Good afternoon': '52.Goodafternoon',
    '36. light': '36.light',
    '39. famous': '39.famous',
    '78. long': '78.long',
    '79. short': '79.short',
    '80. tall': '80.tall',
    '81. wide': '81.wide',
    '66. Sunday': '66.Sunday',
    '67. Monday': '67.Monday',
    '68. Tuesday': '68.Tuesday',
    '69. Wednesday': '69.Wednesday',
    '70. Thursday': '70.Thursday',
    '71. Friday': '71.Friday',
    '72. Saturday': '72.Saturday',
    '73. Today': '73.Today',
}

def canonical_label(label):
    return ALIASES.get(label, label)
