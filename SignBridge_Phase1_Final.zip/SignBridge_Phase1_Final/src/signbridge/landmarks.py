"""MediaPipe Holistic 0.10.21: RGB frames -> T,75,3 body/left/right landmarks."""
import json
from importlib.metadata import version
from pathlib import Path
from time import perf_counter
import cv2
import numpy as np
from .common import digest
from .preprocessing import prepare_candidate

EXTRACTOR_OPTIONS=dict(static_image_mode=False,model_complexity=2,smooth_landmarks=True,
    enable_segmentation=False,smooth_segmentation=True,refine_face_landmarks=False,
    min_detection_confidence=0.5,min_tracking_confidence=0.5)
PREPROCESS_VERSION='stgcn-27-xy-allframes-shoulder-clip-v1'

class HolisticExtractor:
    def __init__(self,expected_assets):
        start=perf_counter()
        if version('mediapipe')!='0.10.21':raise ValueError('This adapter requires mediapipe==0.10.21')
        import mediapipe as mp
        self.mp=mp;self.expected_assets=expected_assets
        base=Path(mp.__file__).parent
        # Setup acquires the heavy model explicitly; never silently fetch it during inference.
        for relative,expected in expected_assets.items():
            path=base/relative
            if not path.is_file():raise ValueError('Extractor model asset missing; run scripts/setup_recognition.py: '+relative)
            if digest(path)!=expected:raise ValueError('Extractor model asset fingerprint mismatch: '+relative)
        self.provenance={'extractor':'mediapipe.solutions.holistic','version':'0.10.21',
                         'options':EXTRACTOR_OPTIONS,'preprocessing':PREPROCESS_VERSION,
                         'model_assets_sha256':expected_assets}
        self.init_seconds=perf_counter()-start
    def extract(self,video,expected_count,cache_dir=None):
        start=perf_counter();source_hash=digest(video)
        metadata=dict(self.provenance,source_sha256=source_hash)
        warnings=[];cache=None
        if cache_dir:
            cache=Path(cache_dir)/(source_hash+'.npz');cache.parent.mkdir(parents=True,exist_ok=True)
            if cache.exists():
                try:
                    with np.load(cache,allow_pickle=False) as f:
                        if json.loads(str(f['metadata']))!=metadata:raise ValueError('provenance changed')
                        x=f['keypoints'].copy();conf=f['confidences'].copy()
                    if len(x)!=expected_count:raise ValueError('frame count changed')
                    features=prepare_candidate(x,conf)
                    return features,self.report(x,conf,True,warnings,perf_counter()-start)
                except (OSError,ValueError,KeyError):warnings.append('Stale or invalid landmark cache ignored and regenerated')
        cap=cv2.VideoCapture(str(video));points=[];confidences=[]
        try:
            # Fresh tracking state per source video. No mirroring, resize, frame dropping or interpolation.
            with self.mp.solutions.holistic.Holistic(**EXTRACTOR_OPTIONS) as holistic:
                while True:
                    ok,frame=cap.read()
                    if not ok:break
                    prediction=holistic.process(cv2.cvtColor(frame,cv2.COLOR_BGR2RGB))
                    parts=[];scores=[]
                    for component,size,is_body in [(prediction.pose_landmarks,33,True),
                            (prediction.left_hand_landmarks,21,False),(prediction.right_hand_landmarks,21,False)]:
                        if component is None:
                            parts.append(np.zeros((size,3),np.float32));scores.append(np.zeros(size,np.float32))
                        else:
                            if len(component.landmark)!=size:raise ValueError('Unexpected landmark count')
                            parts.append(np.array([[p.x,p.y,p.z] for p in component.landmark],np.float32))
                            scores.append(np.array([p.visibility if is_body else 1.0 for p in component.landmark],np.float32))
                    points.append(np.concatenate(parts));confidences.append(np.concatenate(scores))
        finally:cap.release()
        if len(points)!=expected_count:raise ValueError('Decoded frame count changed during extraction')
        if not points:raise ValueError('No frames for extraction')
        x=np.stack(points);conf=np.stack(confidences);features=prepare_candidate(x,conf)
        if cache:
            temp=cache.with_suffix('.tmp')
            with temp.open('wb') as f:np.savez_compressed(f,keypoints=x,confidences=conf,metadata=json.dumps(metadata,sort_keys=True))
            temp.replace(cache)
        return features,self.report(x,conf,False,warnings,perf_counter()-start)
    def report(self,x,c,hit,warnings,elapsed):
        left=int(np.any(c[:,33:54]>0,axis=1).sum());right=int(np.any(c[:,54:]>0,axis=1).sum())
        if left<len(x) or right<len(x):warnings.append('Some hand detections absent; missing components were zero-filled before upstream normalization')
        return {'frames':len(x),'left_hand_detected_frames':left,'right_hand_detected_frames':right,
                'cache_hit':hit,'seconds':elapsed,'warnings':warnings,'provenance':self.provenance}
