from collections import Counter
from .labels import canonical_label, LABEL_MAPPING_VERSION
from .dataset_validation import leakage_issues

def select_development(rows, allow_training_overlap=False):
    if leakage_issues(rows): raise ValueError('Split leakage found; diagnostic selection blocked')
    allowed={'val','validation','dev'}
    if allow_training_overlap:allowed.add('train')
    chosen=[r for r in rows if r.get('official_split') in allowed and r['decode_status']=='ok']
    if not chosen: raise ValueError('No explicitly labelled usable development samples; test data is never selected')
    return chosen

def summarize(results):
    successful=[r for r in results if r.get('status')=='ok' and r.get('predicted_label') is not None]
    pairs=[(canonical_label(r['expected_label']),canonical_label(r['predicted_label'])) for r in successful]
    confused=Counter((a,b) for a,b in pairs if a!=b)
    return {'label_mapping_version':LABEL_MAPPING_VERSION,'attempted':len(results),'evaluated':len(successful),'classes_represented':sorted({a for a,b in pairs}),
            'top1_accuracy':sum(a==b for a,b in pairs)/len(successful) if successful else None,
            'failures':len(results)-len(successful), 'confusions':[{'expected':a,'predicted':b,'count':n} for (a,b),n in confused.items()],
            'accuracy_denominator':'successfully processed samples; see failures and accuracy_all_attempts',
            'accuracy_all_attempts':sum(a==b for a,b in pairs)/len(results) if results else None,
            'results':results,'training_overlap':'Cannot be ruled out; not independent generalization evidence'}
