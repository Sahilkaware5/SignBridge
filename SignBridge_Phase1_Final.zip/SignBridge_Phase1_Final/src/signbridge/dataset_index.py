import csv
from collections import Counter
from pathlib import Path
from .common import digest, stable_id, safe_path
from .dataset_validation import probe_video, leakage_issues
from .labels import canonical_label, LABEL_MAPPING_VERSION
EXTENSIONS = {'.mp4', '.avi', '.mov', '.mkv', '.webm', '.m4v'}

def index_dataset(root, metadata=None, layout='metadata'):
    root = Path(root).resolve()
    if not root.is_dir(): raise ValueError('Dataset root does not exist')
    warnings = []
    if metadata:
        with open(metadata, newline='', encoding='utf-8-sig') as f: entries = list(csv.DictReader(f))
        if entries and not {'relative_video_path','original_label'}.issubset(entries[0]):
            raise ValueError('Metadata needs relative_video_path and original_label columns')
    elif layout == 'class-folders':
        entries = []
        for p in sorted(root.rglob('*')):
            if p.suffix.lower() not in EXTENSIONS or not p.is_file(): continue
            rel = p.relative_to(root)
            # Explicit layout: root/class/video only; deeper trees require metadata.
            label = rel.parts[0] if len(rel.parts) == 2 else None
            entries.append({'relative_video_path': str(rel), 'original_label': label})
        warnings.append('Labels inferred only from explicit root/class/video layout; nested paths require metadata')
    else: raise ValueError('Supply --metadata or explicitly select --layout class-folders')
    rows = []
    for e in entries:
        rel = e.get('relative_video_path', '')
        if not rel: raise ValueError('Empty video path in metadata')
        path = safe_path(root, rel)
        label = e.get('original_label') or None
        r = {k: e.get(k) or None for k in ['signer_id','session_id','source_id','official_split','near_duplicate_group']}
        r.update(sample_id='sample_' + stable_id(rel)[4:], relative_video_path=rel,
                 original_label=label, canonical_label=canonical_label(label),
                 label_mapping_version=LABEL_MAPPING_VERSION,
                 source_class_id=stable_id(label) if label else None,
                 class_id=stable_id(canonical_label(label)) if label else None,
                 sha256=digest(path) if path.is_file() else None)
        r.update(probe_video(path))
        if label is None: r.update(decode_status='error', failure_reason='missing_label_or_unexpected_layout')
        rows.append(r)
    known = {r['relative_video_path'] for r in rows}
    unindexed = [str(p.relative_to(root)) for p in root.rglob('*')
                 if p.is_file() and p.suffix.lower() in EXTENSIONS and str(p.relative_to(root)) not in known]
    counts = Counter(r['canonical_label'] for r in rows if r['decode_status'] == 'ok')
    hashes = Counter(r['sha256'] for r in rows if r['sha256'])
    report = {'entries_examined': len(rows), 'usable_entries': sum(counts.values()),
              'unique_local_files': len({r['relative_video_path'] for r in rows if r['sha256']}),
              'label_mapping_version': LABEL_MAPPING_VERSION,
              'original_label_counts': dict(Counter(r['original_label'] for r in rows if r['decode_status']=='ok')),
              'classes_with_usable_files': len(counts), 'usable_per_class': dict(sorted(counts.items())),
              'failures': [dict(path=r['relative_video_path'], reason=r['failure_reason']) for r in rows if r['decode_status'] != 'ok'],
              'duplicate_hashes': {k:v for k,v in hashes.items() if v>1}, 'unindexed_videos': unindexed,
              'few_recordings': {k:v for k,v in counts.items() if v<5},
              'split_leakage': leakage_issues(rows), 'warnings': warnings,
              'signer_independence_established': False,
              'near_duplicates': 'Not automatically resolved. Supply reviewed near_duplicate_group/source_id metadata before splitting.',
              'quality_scope': 'Full sequential decoding and container checks; no linguistic or landmark-quality verification.'}
    return rows, report
