import argparse
import sys
from pathlib import Path
from .common import save, load, safe_path

def main(command=None):
    p=argparse.ArgumentParser(description='SignBridge Phase 1: offline dataset and compatibility tools')
    sub=p.add_subparsers(dest='command',required=True)
    e=sub.add_parser('environment'); e.add_argument('--out',default='reports/environment.json')
    i=sub.add_parser('inspect'); i.add_argument('root'); i.add_argument('--metadata'); i.add_argument('--layout',choices=['metadata','class-folders'],default='metadata'); i.add_argument('--out',default='data/manifests'); i.add_argument('--config',default='configs/dataset.yaml')
    v=sub.add_parser('vocabulary'); v.add_argument('manifest'); v.add_argument('--target',type=int,default=20);v.add_argument('--minimum',type=int,default=5);v.add_argument('--out',default='reports/vocabulary.json')
    s=sub.add_parser('splits');s.add_argument('manifest');s.add_argument('--out',default='reports/splits.json')
    for name in ['infer','diagnostic']:
        c=sub.add_parser(name);c.add_argument('input');c.add_argument('--config',default='configs/model_stgcn.yaml');c.add_argument('--out',default='reports/'+name+'.json')
        c.add_argument('--device',choices=['cpu'],default='cpu');c.add_argument('--cache-dir')
        if name=='diagnostic':
            c.add_argument('--root',required=True);c.add_argument('--limit',type=int,default=10)
            c.add_argument('--allow-training-overlap',action='store_true',help='Permit original train recordings for pipeline checks, NOT independent accuracy')
    a=p.parse_args(([command]+sys.argv[1:]) if command else None)
    try:
        if a.command=='environment':
            from .environment import inspect
            result=inspect()
        elif a.command=='inspect':
            import yaml
            from .dataset_index import index_dataset
            from .vocabulary import propose
            config=yaml.safe_load(Path(a.config).read_text())
            rows,result=index_dataset(a.root,a.metadata,a.layout)
            dest=Path(a.out);save(dest/'manifest.json',rows);save(dest/'inspection.json',result)
            save(dest/'vocabulary.json',propose(rows,config['target_classes'],config['minimum_unique_development_samples']))
            print(f"Indexed {len(rows)} entries; {result['usable_entries']} usable. Reports: {dest}")
            return 0
        elif a.command=='vocabulary':
            from .vocabulary import propose
            result=propose(load(a.manifest),a.target,a.minimum)
        elif a.command=='splits':
            from .splits import plan
            result=plan(load(a.manifest))
        elif a.command=='infer':
            from .inference import run
            result=run(a.input,a.config,cache_dir=a.cache_dir,device=a.device)
            if result.get("predicted_label"):
                print("Predicted:",result["predicted_label"])
                print("Top model scores:",[(x["label"],round(x["model_score"],4)) for x in result["top_candidates"]])
        else:
            from .diagnostics import select_development,summarize
            from .inference import run,RecognitionPipeline
            from .labels import canonical_label
            from .common import digest
            from collections import defaultdict
            from time import perf_counter
            rows=select_development(load(a.input),a.allow_training_overlap)
            if a.limit<1: raise ValueError('limit must be positive')
            # Deterministic round-robin coverage; selected without looking at predictions.
            groups=defaultdict(list)
            for r in sorted(rows,key=lambda r:r['relative_video_path']):groups[canonical_label(r['original_label'])].append(r)
            chosen=[]
            while len(chosen)<a.limit and any(groups.values()):
                for label in sorted(groups):
                    if groups[label] and len(chosen)<a.limit:chosen.append(groups[label].pop(0))
            batch_start=perf_counter();pipeline=RecognitionPipeline(a.config,a.device)
            results=[]
            for r in chosen:
                path=safe_path(a.root,r['relative_video_path'])
                if not path.is_file() or digest(path)!=r.get('sha256'):
                    out={'status':'error','failure_reason':'Manifest file missing or hash changed; re-index before evaluation',
                         'predicted_label':None,'input_sample_identifier':r['sample_id']}
                else:out=run(path,a.config,pipeline,cache_dir=a.cache_dir,device=a.device)
                out['expected_label']=r['original_label'];out['official_split']=r['official_split']
                out['relative_video_path']=r['relative_video_path'];results.append(out)
            result=summarize(results)
            from .environment import inspect
            result.update(model_load_seconds=pipeline.model.load_seconds,
                          extractor_init_seconds=pipeline.extractor.init_seconds,
                          total_batch_seconds=perf_counter()-batch_start,
                          hardware=inspect(),signer_independence_established=False,
                          allowed_training_overlap=a.allow_training_overlap,
                          final_test_used=False)
            print('Evaluated:',result['evaluated'],'Failures:',result['failures'],'Top-1:',result['top1_accuracy'])
            print('Pipeline diagnostic only; not independent generalization evidence.')
        save(a.out,result)
        print(f"Saved {a.out}")
        if isinstance(result,dict) and result.get('status') in ('blocked','error'):
            print(result.get('failure_reason')); return 2
        if a.command=='diagnostic' and result['evaluated']==0: return 2
        return 0
    except (ValueError,OSError,KeyError,RuntimeError,ImportError) as e:
        save(a.out if a.command!='inspect' else Path(a.out)/'error.json',{'status':'error','failure_reason':str(e)})
        print(str(e),file=sys.stderr);return 2

if __name__=='__main__': sys.exit(main())
