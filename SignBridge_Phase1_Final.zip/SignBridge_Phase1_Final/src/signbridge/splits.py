import hashlib
from .dataset_validation import leakage_issues

def plan(rows, seed='signbridge-1'):
    """Connected components keep every shared signer/source/hash in one split."""
    official = [r.get('official_split') for r in rows]
    if any(official):
        if not all(official): raise ValueError('Mixed official/unassigned splits; reconcile metadata first')
        issues = leakage_issues(rows)
        if issues: raise ValueError('Official split conflicts require review: ' + str(issues[:3]))
        return [dict(r, planned_split=r['official_split']) for r in rows]
    if any(not r.get('signer_id') for r in rows):
        raise ValueError('Signer-independent split blocked: signer metadata unavailable')
    parent = list(range(len(rows)))
    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]; i = parent[i]
        return i
    seen = {}
    for i,r in enumerate(rows):
        for key in ['sample_id','relative_video_path','signer_id','source_id','sha256','near_duplicate_group']:
            value = r.get(key)
            if value is None or value == '': continue
            token = (key, value)
            if token in seen: parent[find(i)] = find(seen[token])
            seen[token] = i
    groups = {}
    for i,r in enumerate(rows): groups.setdefault(find(i), []).append(r['sample_id'])
    if len(groups)<3: raise ValueError('Fewer than three independent groups; cannot create three splits')
    ordered = sorted(groups, key=lambda g: hashlib.sha256((seed+min(groups[g])).encode()).hexdigest())
    n = len(ordered); nt = max(1,round(n*.15)); nv=max(1,round(n*.15))
    assignments = {g: ('test' if j<nt else 'val' if j<nt+nv else 'train') for j,g in enumerate(ordered)}
    result = [dict(r, planned_split=assignments[find(i)]) for i,r in enumerate(rows)]
    if leakage_issues(result, 'planned_split'): raise ValueError('Internal grouping error')
    return result
