"""Source-derived transformations shared by the verified ST-GCN adapter and software tests."""
import json
import numpy as np
from .common import digest
MINIMAL_27 = [0,2,5,11,12,13,14,33,37,38,41,42,45,46,49,50,53,54,58,59,62,63,66,67,70,71,74]

def prepare_candidate(keypoints, confidences):
    """T,75,3 in upstream body33/left21/right21 order -> 1,2,T,27.
    Keeps every frame. Matches source clip-level shoulder centering/scaling.
    Conservative rejection policy is OUR policy; a conservative input-quality policy, not a learned rejection rule.
    """
    x = np.asarray(keypoints, dtype=np.float32)
    c = np.asarray(confidences, dtype=np.float32)
    if x.ndim != 3 or x.shape[1:] != (75,3) or len(x)==0 or c.shape != x.shape[:2]:
        raise ValueError('Expected nonempty T,75,3 keypoints and T,75 confidence')
    if not np.isfinite(x).all() or not np.isfinite(c).all(): raise ValueError('Non-finite landmarks')
    if not np.any(c[:,33:] > 0): raise ValueError('No hand landmarks detected')
    if np.any(c[:,[11,12]] <= 0): raise ValueError('Missing shoulder landmarks; normalization unavailable')
    points = x[:, MINIMAL_27, :2].copy()
    a,b = points[:,3],points[:,4]
    scale = np.linalg.norm(a-b,axis=1).mean()
    if scale <= 1e-8: raise ValueError('Degenerate shoulder distance')
    points = (points - ((a+b)/2).mean(axis=0)) / scale
    out = points.transpose(2,0,1)[None].astype(np.float32)
    if not np.isfinite(out).all(): raise ValueError('Non-finite normalized output')
    return out

def cache_features(path, features, source, extractor_version, config):
    provenance = {'source_sha256': digest(source), 'extractor_version': extractor_version,
                  'config': config, 'status': 'candidate_not_checkpoint_verified'}
    np.savez_compressed(path, features=features, metadata=json.dumps(provenance,sort_keys=True))

def read_cache(path, source, extractor_version, config):
    with np.load(path, allow_pickle=False) as f:
        m = json.loads(str(f['metadata']))
        if (m['source_sha256'],m['extractor_version'],m['config']) != (digest(source),extractor_version,config):
            raise ValueError('Stale feature cache')
        return f['features'].copy()
