import re
from collections import defaultdict
from .labels import canonical_label
from .common import stable_id

def propose(rows, target=20, minimum=5, compatible_labels=None):
    if not 1 <= target <= 50: raise ValueError('target must be 1..50')
    groups = defaultdict(list)
    for r in rows:
        if r['decode_status'] == 'ok' and r['original_label'] and r.get('official_split') != 'test':
            groups[canonical_label(r['original_label'])].append(r)
    candidates = []
    for label, items in groups.items():
        unique = {r['sha256'] for r in items if r.get('sha256')}
        if len(unique) < minimum: continue
        if compatible_labels is not None and label not in {canonical_label(x) for x in compatible_labels}: continue
        signers = {r['signer_id'] for r in items if r.get('signer_id')}
        candidates.append({'canonical_label': label,
            'original_label': items[0]['original_label'],
            'source_labels': sorted({r['original_label'] for r in rows if canonical_label(r.get('original_label')) == label}),
            'display_name': re.sub(r'^\d+\.\s*', '', label),
            'class_id': stable_id(label), 'usable_samples': len(unique),
            'known_signers': len(signers) if signers else None,
            'reason': 'Ranked by distinct decodable non-test recordings, then known signer coverage',
            'limitations': ['Practical relevance needs signer/student review', 'Visual quality not manually verified'] +
                ([] if compatible_labels is not None else ['Checkpoint label compatibility unverified']) +
                ([] if len(signers)==len({r.get('signer_id') for r in items}) else ['Signer metadata incomplete'])})
    candidates.sort(key=lambda r: (-r['usable_samples'], -(r['known_signers'] or 0), r['canonical_label']))
    selected = candidates[:target]
    return {'status': 'provisional_training_target' if selected else 'blocked_no_usable_evidence',
            'requested_classes': target, 'supported_classes': len(selected), 'classes': selected,
            'note': 'Not the pretrained recognition vocabulary. Final test entries excluded from selection.'}
