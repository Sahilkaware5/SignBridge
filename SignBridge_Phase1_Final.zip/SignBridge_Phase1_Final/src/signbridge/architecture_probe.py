"""Structural probe reproducing upstream layouts; never used for recognition.
Derived from Apache-2.0 OpenHands (AI4Bharat); see THIRD_PARTY_NOTICES.md.
"""
import torch
from torch import nn

class Attention(nn.Module):
    def __init__(self):
        super().__init__();self.fc1=nn.Linear(256,256,bias=False);self.fc2=nn.Linear(512,256,bias=False)
    def forward(self,x):
        final=x[:,-1,:]
        score=torch.bmm(self.fc1(x),final.unsqueeze(2)).squeeze(2)
        context=torch.bmm(x.transpose(1,2),torch.softmax(score,dim=1).unsqueeze(2)).squeeze(2)
        return torch.tanh(self.fc2(torch.cat([context,final],dim=1)))

class DecoderProbe(nn.Module):
    def __init__(self):
        super().__init__();self.rnn=nn.LSTM(54,128,num_layers=4,bidirectional=True)
        self.attn_block=Attention();self.fc=nn.Linear(256,263)
    def forward(self,x):
        out,_=self.rnn(x)
        return self.fc(self.attn_block(out))

class NetworkProbe(nn.Module):
    def __init__(self):
        super().__init__();self.decoder=DecoderProbe()
    def forward(self,x):return self.decoder(x.permute(0,2,1,3).flatten(start_dim=2))

class CheckpointProbe(nn.Module):
    def __init__(self):super().__init__();self.model=NetworkProbe()
    def forward(self,x):return self.model(x)
