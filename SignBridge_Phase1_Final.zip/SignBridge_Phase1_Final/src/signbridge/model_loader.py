import json
from pathlib import Path
from time import perf_counter
import numpy as np
import yaml
from .common import digest

class AssetBlocked(RuntimeError): pass
class LegacyCheckpointMetadata: pass
class LegacyEarlyStopMetadata: pass

def validate_outputs(logits, labels):
    x=np.asarray(logits)
    if not labels or len(set(labels))!=len(labels):raise ValueError('Missing or duplicate checkpoint labels')
    if x.shape!=(1,len(labels)):raise ValueError('Checkpoint output dimensions do not match label map')
    if not np.isfinite(x).all():raise ValueError('Non-finite model outputs')
    return x

def read_config(config_path):
    path=Path(config_path).resolve()
    with path.open() as f:c=yaml.safe_load(f)
    if c.get('adapter')!='openhands-include-stgcn-v1':
        raise AssetBlocked('This is the legacy blocked configuration. Use configs/model_stgcn.yaml for the recognition adapter.')
    c['_config_dir']=str(path.parent)
    return c

def resolve_asset(c,key):
    return (Path(c['_config_dir'])/c[key]).resolve()

class LoadedModel:
    def __init__(self,config_path,device='cpu'):
        start=perf_counter()
        self.config=read_config(config_path);c=self.config
        try:import torch
        except ImportError as e:raise AssetBlocked('PyTorch missing. Activate .venv-recognition and install requirements-recognition.txt.') from e
        from .stgcn_model import ReleasedSTGCN
        if device!='cpu':raise ValueError('Only CPU has been validated for this adapter. Use --device cpu.')
        checkpoint=resolve_asset(c,'checkpoint_path');label_path=resolve_asset(c,'label_map_path')
        if not checkpoint.is_file():raise AssetBlocked('Checkpoint missing. Run python scripts/setup_recognition.py first.')
        if digest(checkpoint)!=c['checkpoint_sha256']:raise ValueError('Checkpoint SHA256 mismatch; refusing incompatible weights')
        if digest(label_path)!=c['label_map_sha256']:raise ValueError('Label map SHA256 mismatch; never reorder classifier labels')
        self.labels=json.loads(label_path.read_text())
        if len(self.labels)!=263 or len(set(self.labels))!=263:raise ValueError('Expected 263 unique original checkpoint labels')
        allow=[(LegacyCheckpointMetadata,'pytorch_lightning.callbacks.model_checkpoint.ModelCheckpoint'),
               (LegacyEarlyStopMetadata,'pytorch_lightning.callbacks.early_stopping.EarlyStopping')]
        with torch.serialization.safe_globals(allow):
            blob=torch.load(checkpoint,map_location='cpu',weights_only=True)
        state=blob['state_dict'];self.model=ReleasedSTGCN()
        # Check graph semantics BEFORE loading, since A is also a checkpoint buffer.
        if not torch.equal(state['model.encoder.A'],self.model.model.encoder.A):
            raise ValueError('Checkpoint graph adjacency differs from released distance-partition graph')
        if any(not torch.isfinite(v).all().item() for v in state.values()):raise ValueError('Non-finite checkpoint weights')
        result=self.model.load_state_dict(state,strict=True)
        self.model.to(device).eval();self.device=device
        torch.set_num_threads(2)
        self.verification={'checkpoint_sha256':c['checkpoint_sha256'],'label_map_sha256':c['label_map_sha256'],
            'original_lightning_version':blob.get('pytorch-lightning_version'),'missing_weights':list(result.missing_keys),
            'unexpected_weights':list(result.unexpected_keys),'output_classes':263,'graph_adjacency_matches':True,
            'torch_version':torch.__version__,'device':device}
        self.load_seconds=perf_counter()-start
    def predict(self,features):
        import torch
        x=np.asarray(features,dtype=np.float32)
        if x.ndim!=4 or x.shape[0]!=1 or x.shape[1]!=2 or x.shape[2]<1 or x.shape[3]!=27 or not np.isfinite(x).all():
            raise ValueError('Expected finite [1,2,T,27] features with T>0')
        start=perf_counter()
        with torch.inference_mode():
            logits=self.model(torch.from_numpy(x).to(self.device)).cpu().numpy()
        elapsed=perf_counter()-start
        return validate_outputs(logits,self.labels)[0],elapsed

def load_verified_model(config_path,device='cpu'):
    return LoadedModel(config_path,device)
