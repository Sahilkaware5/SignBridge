import platform
import sys
import os
import subprocess
from importlib.metadata import version, PackageNotFoundError

def inspect():
    packages = {}
    for p in ['numpy', 'opencv-python-headless', 'opencv-contrib-python', 'PyYAML', 'torch', 'mediapipe', 'OpenHands', 'pytest', 'pyarrow']:
        try: packages[p] = version(p)
        except PackageNotFoundError: packages[p] = None
    memory = None
    try:
        if platform.system() == 'Darwin':
            memory = int(subprocess.check_output(['sysctl', '-n', 'hw.memsize']))
        else: memory = os.sysconf('SC_PAGE_SIZE') * os.sysconf('SC_PHYS_PAGES')
    except (OSError, ValueError, subprocess.SubprocessError): pass
    devices = {}
    try:
        import torch
        for d, available in [('cpu', True), ('cuda', torch.cuda.is_available()),
                             ('mps', hasattr(torch.backends, 'mps') and torch.backends.mps.is_available())]:
            if not available:
                devices[d] = {'available': False, 'operation_test': 'not run'}
                continue
            try:
                x = torch.ones((4, 4), device=d)
                value = (x @ x).sum().cpu().item()
                devices[d] = {'available': True, 'operation_test': value == 64}
            except Exception as e: devices[d] = {'available': True, 'operation_test': str(e)}
    except ImportError: devices['runtime'] = 'PyTorch not installed; no inference devices verified'
    return {'os': platform.platform(), 'architecture': platform.machine(), 'python': sys.version,
            'python_executable': sys.executable, 'virtual_environment': sys.prefix != sys.base_prefix,
            'memory_bytes': memory, 'packages': packages, 'devices': devices,
            'selected_model_cpu_verified': False, 'selected_model_acceleration_verified': False,
            'note': 'Device arithmetic is not a checkpoint compatibility test. Target Mac must run this command separately.'}
