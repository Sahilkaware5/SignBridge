"""Recognition contracts; checkpoint checks skip explicitly when assets are absent."""
import json
import numpy as np
import pytest
from signbridge.model_loader import LoadedModel,read_config,resolve_asset
from signbridge.preprocessing import prepare_candidate,MINIMAL_27
from signbridge.diagnostics import select_development,summarize

def test_training_opt_in_never_selects_test():
    rows=[dict(sample_id=str(i),relative_video_path=str(i),sha256=str(i),decode_status='ok',official_split=s)
          for i,s in enumerate(['train','test'])]
    with pytest.raises(ValueError,match='No explicitly'):select_development(rows)
    assert select_development(rows,True)==rows[:1]
    rows[1]['source_id']='same';rows[0]['source_id']='same'
    with pytest.raises(ValueError,match='leakage'):select_development(rows,True)

def test_failure_denominator_is_explicit():
    r=summarize([dict(status='ok',expected_label='36. light',predicted_label='36.light'),dict(status='error')])
    assert r['top1_accuracy']==1 and r['accuracy_all_attempts']==0.5 and r['failures']==1

def test_temporal_and_left_right_identity():
    x=np.zeros((7,75,3),np.float32);c=np.ones((7,75),np.float32)
    x[:,11,0]=0.25;x[:,12,0]=0.75
    x[:,33,0]=np.arange(7)/10;x[:,54,1]=0.7
    out=prepare_candidate(x,c)
    np.testing.assert_allclose(out[0,0,:,MINIMAL_27.index(33)],(np.arange(7,dtype=np.float32)/10-.5)/.5)
    np.testing.assert_allclose(out[0,1,:,MINIMAL_27.index(54)],1.4)
    assert out.shape==(1,2,7,27)

def test_one_missing_hand_allowed_but_no_hands_rejected():
    x=np.zeros((3,75,3),np.float32);c=np.ones((3,75),np.float32);x[:,12,0]=1
    c[:,33:54]=0
    assert np.isfinite(prepare_candidate(x,c)).all()
    c[:,54:]=0
    with pytest.raises(ValueError,match='No hand'):prepare_candidate(x,c)

@pytest.fixture(scope='module')
def released():
    pytest.importorskip('torch')
    c=read_config('configs/model_stgcn.yaml')
    if not resolve_asset(c,'checkpoint_path').is_file():pytest.skip('Official checkpoint absent; run setup_recognition.py')
    return LoadedModel('configs/model_stgcn.yaml')

def test_released_variable_length_and_output_labels(released):
    for frames in [1,17,56]:
        y,_=released.predict(np.zeros((1,2,frames,27),np.float32))
        assert y.shape==(263,) and np.isfinite(y).all()
    assert released.verification['missing_weights']==[] and released.verification['unexpected_weights']==[]
    with pytest.raises(ValueError,match='Expected finite'):released.predict(np.zeros((1,17,2,27)))

@pytest.mark.parametrize('change',['missing','unexpected','graph','nonfinite'])
def test_rejects_incompatible_weights(released,monkeypatch,change):
    import torch
    state=dict(released.model.state_dict())
    if change=='missing':state.pop(next(k for k in state if k.endswith('weight')))
    if change=='unexpected':state['unrecognized.weight']=torch.ones(1)
    if change=='graph':state['model.encoder.A']=state['model.encoder.A'].clone()+1
    if change=='nonfinite':
        k=next(k for k,v in state.items() if v.is_floating_point() and k!='model.encoder.A')
        state[k]=torch.full_like(state[k],float('nan'))
    monkeypatch.setattr(torch,'load',lambda *a,**kw:{'state_dict':state})
    with pytest.raises((RuntimeError,ValueError)):LoadedModel('configs/model_stgcn.yaml')

def test_label_reordering_rejected(released,tmp_path):
    import yaml
    c=dict(released.config);c['checkpoint_path']=str(resolve_asset(c,'checkpoint_path'))
    labels=tmp_path/'labels.json';labels.write_text(json.dumps(list(reversed(released.labels))))
    c['label_map_path']=str(labels);config=tmp_path/'model.yaml';config.write_text(yaml.safe_dump(c))
    with pytest.raises(ValueError,match='Label map SHA256'):LoadedModel(config)
