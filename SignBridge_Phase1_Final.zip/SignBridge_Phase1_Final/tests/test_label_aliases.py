import csv
import numpy as np
import cv2
from signbridge.labels import canonical_label
from signbridge.dataset_index import index_dataset
from signbridge.vocabulary import propose
from signbridge.diagnostics import summarize
from signbridge.common import stable_id

def test_exact_mapping_only():
    assert canonical_label('78. long') == '78.long'
    assert canonical_label('78.long') == '78.long'
    assert canonical_label('999. long') == '999. long'
    assert canonical_label('LONG') == 'LONG'

def test_originals_and_splits_preserved(tmp_path):
    for name,brightness in [('train',30),('test',90)]:
        writer=cv2.VideoWriter(str(tmp_path/(name+'.avi')),cv2.VideoWriter_fourcc(*'MJPG'),10,(32,24))
        assert writer.isOpened()
        for i in range(5):writer.write(np.full((24,32,3),brightness+i,np.uint8))
        writer.release()
    metadata=tmp_path/'metadata.csv'
    metadata.write_text('relative_video_path,original_label,official_split\ntrain.avi,78.long,train\ntest.avi,78. long,test\n')
    rows,report=index_dataset(tmp_path,metadata)
    assert [r['original_label'] for r in rows]==['78.long','78. long']
    assert [r['official_split'] for r in rows]==['train','test']
    assert len({r['class_id'] for r in rows})==1
    assert rows[1]['source_class_id']==stable_id('78. long')
    assert report['classes_with_usable_files']==1
    assert report['usable_per_class']=={'78.long':2}
    v=propose(rows,minimum=1)['classes'][0]
    assert v['usable_samples']==1
    assert v['source_labels']==['78. long','78.long']

def test_evaluation_keeps_raw_outputs():
    results=[dict(status='ok',expected_label='78. long',predicted_label='78.long')]
    summary=summarize(results)
    assert summary['top1_accuracy']==1
    assert results[0]['expected_label']=='78. long'
    assert results[0]['predicted_label']=='78.long'
    assert summarize([dict(status='ok',expected_label='78. long',predicted_label='79.short')])['top1_accuracy']==0
