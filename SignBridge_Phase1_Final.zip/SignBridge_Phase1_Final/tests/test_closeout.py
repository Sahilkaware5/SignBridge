"""Regression checks for saved-evidence auditing (not recognition accuracy)."""
import importlib.util
import json
import shutil
from pathlib import Path

spec = importlib.util.spec_from_file_location('closeout', 'scripts/finalize_phase1.py')
closeout = importlib.util.module_from_spec(spec)
spec.loader.exec_module(closeout)

def test_uploaded_evidence_consistency():
    result = closeout.audit(Path('.'))
    assert result['errors'] == []
    assert result['selected_classes'] == 20
    assert result['selected_non_test_recordings'] == 309
    assert result['diagnostic_correct'] == 6
    assert result['phase1_readiness'].startswith('partially_complete')

def test_tampered_label_map_is_rejected(tmp_path):
    for name in ['reports/target20/manifest.json', 'reports/target20/inspection.json',
                 'reports/target20/vocabulary.json', 'models/checkpoint_labels.json',
                 'reports/recognition_setup.json', 'reports/my_stgcn_seven_classes.json']:
        dest = tmp_path / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(name, dest)
    path = tmp_path / 'models/checkpoint_labels.json'
    labels = json.loads(path.read_text())
    labels.reverse()
    path.write_text(json.dumps(labels))
    result = closeout.audit(tmp_path)
    assert result['status'] == 'error'
    assert 'Label map differs from verified setup' in result['errors']

def test_new_aliases_preserve_unknown_labels():
    from signbridge.labels import canonical_label
    for number, word in enumerate(['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Today'], 66):
        assert canonical_label(f'{number}. {word}') == f'{number}.{word}'
    assert canonical_label('999. Sunday') == '999. Sunday'
