import csv
import numpy as np
import cv2
import pytest
from signbridge.dataset_validation import probe_video,leakage_issues
from signbridge.dataset_index import index_dataset
from signbridge.common import stable_id
from signbridge.vocabulary import propose
from signbridge.preprocessing import prepare_candidate,cache_features,read_cache
from signbridge.model_loader import validate_outputs,load_verified_model,AssetBlocked
from signbridge.splits import plan
from signbridge.diagnostics import select_development,summarize
from signbridge.inference import run

def video(p):
    p.parent.mkdir(parents=True,exist_ok=True)
    writer=cv2.VideoWriter(str(p),cv2.VideoWriter_fourcc(*'MJPG'),10,(32,24))
    assert writer.isOpened()
    for i in range(10):writer.write(np.full((24,32,3),i*20,np.uint8))
    writer.release()
    return p

def test_corrupt(tmp_path):
    p=tmp_path/'bad.mp4';p.write_bytes(b'not video')
    assert probe_video(p)['decode_status']=='error'
    assert run(p,'configs/model.yaml')['predicted_label'] is None

def test_empty_and_missing(tmp_path):
    p=tmp_path/'empty.avi';p.touch()
    assert probe_video(p)['failure_reason']=='empty_file'
    assert probe_video(tmp_path/'absent.mp4')['failure_reason']=='missing_file'

def test_decode_and_index(tmp_path):
    video(tmp_path/'7. Hello'/'one.avi')
    rows,report=index_dataset(tmp_path,layout='class-folders')
    assert report['usable_entries']==1
    assert rows[0]['frame_count']==10
    assert rows[0]['original_label']=='7. Hello'
    assert rows[0]['class_id']==stable_id('7. Hello')
    video(tmp_path/'1. Earlier'/'two.avi')
    rows,_=index_dataset(tmp_path,layout='class-folders')
    assert next(r for r in rows if r['original_label']=='7. Hello')['class_id']==stable_id('7. Hello')

def test_layout_and_duplicates(tmp_path):
    p=video(tmp_path/'category'/'word'/'one.avi')
    rows,_=index_dataset(tmp_path,layout='class-folders')
    assert rows[0]['failure_reason']=='missing_label_or_unexpected_layout'
    q=tmp_path/'class'/'two.avi';q.parent.mkdir();q.write_bytes(p.read_bytes())
    _,report=index_dataset(tmp_path,layout='class-folders')
    assert report['duplicate_hashes']

def test_traversal(tmp_path):
    meta=tmp_path/'m.csv';meta.write_text('relative_video_path,original_label\n../escape.mp4,Hello\n')
    with pytest.raises(ValueError,match='escapes'):index_dataset(tmp_path,meta)

def test_output_contract():
    assert validate_outputs([[1,2]],['a','b']).shape==(1,2)
    with pytest.raises(ValueError):validate_outputs([[1,2,3]],['a','b'])
    with pytest.raises(ValueError):validate_outputs([[float('nan')]],['a'])
    with pytest.raises(ValueError):validate_outputs([[1,2]],['a','a'])

def landmarks():
    x=np.zeros((8,75,3),np.float32);x[:,12,0]=1
    return x,np.ones((8,75),np.float32)

def test_shape_and_values():
    x,c=landmarks();out=prepare_candidate(x,c)
    assert out.shape==(1,2,8,27) and np.isfinite(out).all()
    assert out[0,0,0,3]==-.5 and out[0,0,0,4]==.5

def test_missing_landmarks():
    x,c=landmarks();c[:,33:]=0
    with pytest.raises(ValueError,match='No hand'):prepare_candidate(x,c)
    c[:]=1;c[0,11]=0
    with pytest.raises(ValueError,match='shoulder'):prepare_candidate(x,c)
    x[:]=np.nan
    with pytest.raises(ValueError,match='Non-finite'):prepare_candidate(x,c)

def test_stale_cache(tmp_path):
    source=tmp_path/'source';source.write_text('v1');cache=tmp_path/'x.npz'
    cache_features(cache,np.ones((1,2,3,27)),source,'test-version',{'x':1})
    assert read_cache(cache,source,'test-version',{'x':1}).shape==(1,2,3,27)
    source.write_text('v2')
    with pytest.raises(ValueError,match='Stale'):read_cache(cache,source,'test-version',{'x':1})

def rows():
    return [dict(sample_id=str(i),relative_video_path=str(i),signer_id=str(i//2),source_id=None,
                 sha256=str(i),original_label='a',class_id='a',decode_status='ok',official_split=None) for i in range(12)]

def test_split_grouping():
    r=rows();r[0]['sha256']=r[2]['sha256'];out=plan(r)
    assert not leakage_issues(out,'planned_split')
    assert len({x['planned_split'] for x in out})==3
    assert out==plan(r)

def test_unknown_signer_and_official_leakage():
    r=rows();r[0]['signer_id']=None
    with pytest.raises(ValueError,match='Signer'):plan(r)
    r=rows()
    for i,x in enumerate(r):x['official_split']='train' if i%2 else 'test'
    with pytest.raises(ValueError,match='conflicts'):plan(r)

def test_test_exclusion():
    r=rows()
    for x in r:x['official_split']='test'
    assert propose(r,minimum=1)['supported_classes']==0
    with pytest.raises(ValueError):select_development(r)
    assert summarize([])['top1_accuracy'] is None

def test_blocked_model():
    with pytest.raises(AssetBlocked):load_verified_model('configs/model.yaml')

def test_valid_video_does_not_fabricate(tmp_path):
    result=run(video(tmp_path/'a.avi'),'configs/model.yaml')
    assert result['status']=='blocked' and result['predicted_label'] is None
