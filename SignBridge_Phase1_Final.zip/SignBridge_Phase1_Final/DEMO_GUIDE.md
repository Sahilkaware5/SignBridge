# Five-minute Phase 1 demonstration

You do not need to download or reinstall anything on the already-working Mac. Use your existing project folder and .venv-recognition. Keep the data/raw and models/assets directories in place.

1. Explain: “This is offline recognition of isolated Indian Sign Language signs, not continuous translation.”
2. Show reports/target20/vocabulary.json: 20 proposed training classes, 309 non-test recordings; no new model has been trained.
3. Activate the environment and run the known real clip:
```bash
source .venv-recognition/bin/activate
python scripts/run_offline.py "data/raw/Adjectives/36. light/MVI_9711.MOV" --out reports/demo_light.json
```
4. Explain the stages: OpenCV decodes frames → MediaPipe tracks body and both hands → shoulder normalization → ST-GCN models movement → original checkpoint labels and model scores.
5. Show reports/my_stgcn_seven_classes.json: six correct out of seven, Radio wrong. These are training-overlap diagnostic samples, not an independent accuracy benchmark. Light is a tested demonstration clip outside the capped 20-class adaptation target.
6. Explain next work: data review and independent evaluation, then later adaptation. Speech, a webcam interface and sentence suggestions are outside Phase 1.

The measured Mac runs took roughly 4–6 seconds per short clip, mainly landmark extraction. Actual run time may differ. No claim of real-time webcam performance is supported. If the live run fails, show the saved report and explain the failure; do not pass a saved result off as a fresh prediction.
